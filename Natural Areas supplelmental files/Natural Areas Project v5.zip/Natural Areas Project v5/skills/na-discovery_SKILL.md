---
name: na-discovery
description: Executes tier-based discovery of natural areas entities across U.S. counties. Triggers on discover, find parks, catalog entities, tier discovery, or any mention of searching for natural areas in a location.
---

# Natural Areas Project — Discovery Skill v5.2

Executes systematic discovery across all eight tiers for all six entity types.

## Core Rules

**FETCH BEATS SEARCH**: Always web_fetch official pages. Never rely on search snippets alone.
**VIEW MAPS DIRECTLY**: Open Google Maps and view the location. Do not search for map references.
**EXHAUSTIVE BEATS EFFICIENT**: Complete every tier 100% before advancing.
**DOCUMENT NEGATIVES**: Record "no entities found" with evidence. Never assume.
**STAGING FILE IS THE RECORD**: Append each entity immediately. Chat history is not a record.

## Discovery Is Collection Only

During discovery, collect raw values exactly as found:
- No normalization of names, types, or categories
- No correction of spelling or formatting
- No inference of missing values
- No population of `township` or `municipality` — GIS-derived only
- No invention of GPS coordinates — only record what authoritative sources explicitly state
- No assessment of difficulty or accessibility — only record what sources state

## Eight-Tier Sequence

Execute in order. Complete all six entity types per tier before advancing.

| Tier | Governance Level | Sub-Procedure |
|------|-----------------|---------------|
| 1 | Federal & Tribal | `na_fed_tribal_discovery_subproc_v5.2.md` |
| 2 | State | `na_state_discovery_subproc_v5.2.md` |
| 3 | District (Metroparks, conservancy districts) | `na_district_discovery_subproc_v5.2.md` |
| 4 | County | `na_county_discovery_subproc_v5.2.md` |
| 5 | Township | `na_township_discovery_subproc_v5.1.md` |
| 6 | Municipal (cities and villages) | `na_municipal_discovery_subproc_v5.2.md` |
| 7 | Conservancy & Land Trust | `na_conservancy_discovery_subproc_v5.2.md` |
| 8 | Private | `na_private_discovery_subproc_v5.2.md` |

## Entity Type Sequence Within Each Tier

Discover in this order within each tier:
1. Sites
2. Trails
3. Trail Segments
4. Trail Networks
5. Site Networks
6. Access Points

This ordering ensures Sites and Trails exist before Access Points need to reference them as parents.

## Entity Discovery Sub-Procedures

Read when discovering that entity type:
- `na_site_discovery_subproc_v5.3.md`
- `na_trail_discovery_subproc_v5.1.md`
- `na_trail_segment_discovery_subproc_v5.1.md`
- `na_trail_network_discovery_subproc_v5.1.md`
- `na_site_network_discovery_subproc_v5.1.md`
- `na_access_point_discovery_subproc_v5.1.md`

## Raw Discovery Record — Key Fields (v5.2)

Every raw discovery record must include:

```yaml
entity_type:          # Site | Trail | Trail Segment | Trail Network | Site Network | Access Point
name_raw:             # exactly as found
counties_raw: []      # all counties, exactly as found
county_primary:       # county currently being processed
ownership_raw:        # exactly as found
governance_raw:       # exactly as found
partner_agencies_raw: # exactly as found
coordination_raw:     # exactly as found
gps_lat_raw:          # only if explicitly stated by authoritative source
gps_lon_raw:          # only if explicitly stated by authoritative source
location_raw:         # Sites and Access Points only
features_raw:         # Sites and Access Points only
difficulty_raw:       # Trails and Trail Segments only
accessibility_raw:    # Trails and Trail Segments only
urls_raw: []          # ALL urls including maps, PDFs, GIS viewers
identity_notes_raw:   # identity clarifications, conflicts, uncertainty flags
township_raw:         # BLANK — GIS-derived only
municipality_raw:     # BLANK — GIS-derived only
discovery_tier:       # integer 1-8
seeded_from_baseline: # true | false
baseline_id:          # if baseline-seeded
```

Note: `gps_raw` is retired. Always use `gps_lat_raw` and `gps_lon_raw` as separate fields.
Note: `notes_raw` is retired. Use `identity_notes_raw`.
Note: `maps_raw` is retired. Map URLs go into `urls_raw`.

## Null Tier Results

When a tier yields zero entities, record explicitly:

```yaml
tier_result:
  tier: [number]
  governance_level: [name]
  result: null
  entities_found: 0
  sources_checked: [list what was searched and fetched]
  notes: [what evidence supports the null result]
```

Never leave a tier undocumented. A null result with evidence is valid. An undocumented tier is not.

## Baseline Seed Tracking

As you discover entities, check them against baseline seeds:
- When a discovered entity matches a baseline seed, record `seeded_from_baseline: true` and the `baseline_id`
- Mark the seed as confirmed in the session log
- At tier completion, note which seeds remain unconfirmed
- Unconfirmed seeds at the end of all tiers are flagged for review — not automatically included in output

## Municipal Tier — Critical Rules

The municipal tier (Tier 6) is the most common source of missed entities:

- Never skip a village because it seems too small
- Never mark a village as 0 parks without map-based verification
- Always view Google Maps directly for each municipality — do not search for map references
- Official municipal websites are often incomplete or outdated — verify independently with maps
- If browser tools are unavailable, mark the municipality as PENDING/UNVERIFIED — never mark complete without verification

## Cross-County Entities

Entities spanning multiple counties (trail networks, site networks, metropark systems):
- Record all counties in `counties_raw`
- Discover and record the entity fully at its governance tier
- Member IDs will be blank or partial — this is correct and expected
- Do not hold up tier completion waiting for member resolution
- The pipeline will hold these entities pending cross-county resolution

## GPS During Discovery

- Only record GPS if an authoritative source explicitly provides coordinates
- Never derive GPS from maps, proximity, or inference during discovery
- Never record GPS from Google Maps pin locations unless the authoritative source confirms those coordinates
- Blank GPS is correct and expected — GPS Acquisition Module handles missing coordinates downstream

## After All Tiers Complete

1. Confirm all baseline seeds are confirmed or flagged
2. Confirm all tiers have results (including null results with evidence)
3. Update the handoff document
4. Pass staging file to Resolution via na-pipeline skill
