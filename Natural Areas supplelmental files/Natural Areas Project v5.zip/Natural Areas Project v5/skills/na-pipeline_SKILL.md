---
name: na-pipeline
description: Executes the Natural Areas Project pipeline after discovery — resolution, normalization, GPS acquisition, TSV output, and database upsert. Triggers on resolve, normalize, generate TSV, upsert, pipeline, or post-discovery processing.
---

# Natural Areas Project — Pipeline Skill v5.2

Executes all post-discovery pipeline stages: Resolution → Normalization → GPS Acquisition → TSV Output → Database Upsert.

## Pipeline Overview

```
Raw Discovery Records (staging file)
        ↓
Stage 1: Resolution Engine v5.4
        ↓
Stage 2: Normalization Engine v5.5
        ↓
Stage 3: GPS Acquisition Module v5.0 (for entities with blank GPS)
        ↓
Stage 4: TSV Output (six files, one per entity type)
        ↓
Stage 5: TSV Integrity Check v5.2
        ↓
Stage 6: Database Upsert (SQLite via Entity Upsert Engine v5.1)
```

## Stage 1 — Resolution Engine v5.4

Transforms raw discovery records into resolved entities by detecting identity, merging duplicates, and preserving conflicts.

**Five phases:**
1. **Grouping** — partition records by `(entity_type, county_primary)`
2. **Identity Matching** — apply anchors and similarity scoring
3. **Merge Decisions** — form clusters above MERGE_THRESHOLD; flag review sets
4. **Field-Level Merging** — merge raw values using deterministic strategies
5. **Parent Resolution** — resolve parent names to IDs; preserve lineage metadata

**Key rules:**
- Resolution is purely mechanical — it does not normalize, infer, or choose between conflicting values
- All raw values are preserved exactly
- Conflicts are recorded, not resolved — Normalization resolves them
- Multi-county records are placed in all relevant county groups
- Resolution does not modify raw metadata

**Field merge strategies:**
- `choose_or_conflict` — name, location, organizational fields
- `union` — counties, URLs, partner agencies
- `conflict` — GPS lat/lon, lengths, acreage
- `metadata_union` — all metadata blocks
- `parent_resolution` — parent_*_raw lists

Reference: `na_resolution_engine_v5.4.md`, `na_resolution_rules_v5.3.md`

## Stage 2 — Normalization Engine v5.5

Transforms resolved entities into normalized entities ready for TSV output and database upsert.

**Key normalizations (all entity types):**
- Schema validation against Schema Modules v5.x
- Vocabulary normalization against Vocabulary Modules v5.x
- County normalization: semicolon-delimited, alphabetized, "County" suffix stripped
- GPS validation: parse to numeric, validate ranges, round to 6 decimal places
- Plus Code computation from validated GPS
- GIS spatial lookup: derive `township` and `municipality` from GPS coordinates
- Integrity anchor dedup check against current run and existing graph entities
- Parent/child validation

**Per-entity routing:**
- Sites: category, subtype, designation, features, GPS, Plus Code, GIS, Derived Label
- Trails: use type, surface type, origin type, difficulty, maps URL list, identity notes
- Trail Segments: segment type, surface type, difficulty, geometry, maps URL list, identity notes
- Trail Networks: network type, member trail IDs validation, maps URL list, identity notes
- Site Networks: network type, member site IDs validation, identity notes
- Access Points: type, features, GPS (required), Plus Code, GIS, Derived Label, identity notes

**Note**: Derived Label is computed for Sites and Access Points only. It is not computed for Trails, Trail Segments, Trail Networks, or Site Networks.

**Outcomes:**
- `normalized` — ready for upsert
- `rejected` — fatal validation errors
- `held` — valid but incomplete (see held entity rules below)

Reference: `na_normalization_engine_v5.5.md`

## Stage 3 — GPS Acquisition Module v5.0

Handles entities with missing GPS coordinates. Read `na_gps_acquisition_v5.0.md` for the full 11-step, 5-stage workflow.

Entities with GPS acquired in this stage re-enter normalization for Plus Code computation and GIS derivation.

## Held Entity Rules

Entities are held (not rejected) when valid but incomplete:

| Hold Reason | Trigger | Release Condition |
|-------------|---------|-------------------|
| `missing_gps` | Access Point without GPS after GPS Acquisition | GPS acquired in subsequent run |
| `unresolved_member_ids` | Network with unresolved member IDs | Member entities added to graph |
| `unresolved_parent` | Entity whose parent not yet in graph | Parent entity added to graph |

Held entities are stored in the `held_entities` table and checked on every subsequent run.

Cross-county networks (metropark systems, national trail networks, national heritage areas) will be held until all relevant counties are processed. This is correct behavior.

## Stage 4 — TSV Output

Six TSV files produced, one per entity type:

| File | Fields | Tabs |
|------|--------|------|
| `{county}_sites.tsv` | 25 | 24 |
| `{county}_trails.tsv` | 19 | 18 |
| `{county}_trail_segments.tsv` | 17 | 16 |
| `{county}_trail_networks.tsv` | 17 | 16 |
| `{county}_site_networks.tsv` | 15 | 14 |
| `{county}_access_points.tsv` | 17 | 16 |

Reference specs: `na_tsv_output_site_v5.2.md`, `na_tsv_output_trail_v5.1.md`, etc.

## Stage 5 — TSV Integrity Check v5.2

Run against all six TSV files before upsert. Checks:
- Exact delimiter counts per entity type
- No internal tabs or newlines
- True blank fields (no placeholders)
- No leading/trailing whitespace
- All anchor fields in correct positions
- Identity anchor fields populated
- Counties semicolon-delimited and alphabetized
- No multi-row expansion

If any row fails, pipeline halts. All failures logged before halting.

Reference: `na_tsv_integrity_check_v5.2.md`

## Stage 6 — Database Upsert

Writes normalized entities to SQLite database via Entity Upsert Engine v5.1.

**Intent flags:**
- `insert` — new entity
- `update` — existing entity matched on integrity anchor
- `hold` — valid but incomplete; written to `held_entities` table
- `review` — collision detected; written to `manual_review_queue`

**Core tables:** `sites`, `trails`, `trail_segments`, `trail_networks`, `site_networks`, `access_points`

**Relationship tables:** `site_parent`, `trail_to_segment`, `trail_to_network`, `site_to_network`, `access_point_parents`

**Operational tables:** `held_entities`, `manual_review_queue`, `entity_conflicts`, `entity_uncertainty`, `entity_geometry`

**Provenance tables:** `discovery_provenance`, `resolution_provenance`, `normalization_provenance`, `run_metadata`

All provenance tables are append-only. Prior run records are never overwritten.

Reference: `na_entity_upsert_engine_v5.1.md`
