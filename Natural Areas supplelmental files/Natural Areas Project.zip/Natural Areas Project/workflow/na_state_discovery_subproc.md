# STATE LANDS DISCOVERY SUB‑PROCEDURE v4.0
### Tier 2 — State‑Managed and State‑Affiliated Lands  
### Extraction‑First Architecture (v4.0 Standard)

This module defines the authoritative, deterministic Tier‑2 discovery rules for
state‑managed and state‑affiliated lands within the v4.0 Raw → Resolution →
Normalization → Entity Graph pipeline.

This document supersedes all v3.x state‑tier discovery logic.  
This module contains no controlled vocabularies.  
All vocabularies are defined in the appropriate v4.0 Vocabulary Modules.


---

## 1. TIER DEFINITION & PURPOSE

Tier 2 governs discovery of all Sites, Trails, Trail Segments, Trail Networks,
Site Networks, and Access Points managed or co‑managed by state‑level entities.

Tier 2 must:

- Identify all state‑managed Sites  
- Identify child Sites within state Sites  
- Identify Trails, Trail Segments, and Trail Networks on state lands  
- Identify Site Networks (e.g., Scenic River systems)  
- Identify Access Points associated with state Sites  
- Distinguish ODNR divisions, OHC, ODOT, OTIC, EPA/ODA, and co‑management  
- Avoid false positives from similarly named places  
- Produce Raw Discovery Records v4.0  
- Produce Discovery Metadata v4.0  


---

2. Inclusion and exclusion rules
2.1 Included state entities
ODNR divisions:
- Parks & Watercraft
- Forestry
- Wildlife
- Natural Areas & Preserves (DNAP)
- Scenic Rivers Program
- Mineral Resources (surface‑managed lands only)
- Historic Places Program
- Fish Hatcheries Program
- Waterway Management
Quasi‑state organizations:
- Ohio History Connection (OHC)
Other state‑level landholders:
- ODOT
- OTIC
- EPA / DEFA
- ODA
- State universities (natural‑resource lands only)
2.2 Included facility and parcel types
State‑owned operational & ecological facilities:
- Fish hatcheries
- Wildlife research stations
- State nurseries
- Water control structures
- Dam complexes, spillways, tailwaters units
- State‑owned ecological preserves not designated by DNAP
State‑owned monuments & historic features:
- State‑owned monuments
- State‑owned memorial stones
- State‑owned archaeological features
- State‑owned historic structures not in OHC
State‑owned parcels not listed publicly:
- Unnamed ODNR parcels
- Buffer parcels
- Habitat management parcels
- Access parcels
- State‑owned river/stream parcels
- State‑owned lake control parcels
2.3 Exclusions
- Administrative offices
- Maintenance yards
- Non‑identity‑bearing parcels with no natural‑resource relevance


---

## 3. STATE‑LEVEL EXTRACTION METHODOLOGIES (PRIMARY ENGINE)

Tier 2 must extract all state‑managed entities using the following authoritative,
deterministic methodologies.

---

### 3.1 ODNR LANDS & FACILITIES — PARCEL‑LEVEL EXTRACTION (MANDATORY)

**Primary Enumerative Source (ODNR Find‑a‑Property):**  
https://ohiodnr.gov/go-and-do/plan-a-visit/find-a-property/find-a-property-search?type= 

**Examples of valid substitutions:**
- Wildlife Areas → `type=State%20Wildlife%20Area`  
- State Parks → `type=State%20Park`  
- State Forests → `type=State%20Forest`  
- State Nature Preserves → `type=State%20Nature%20Preserve`  

**Purpose:** Extract all ODNR‑owned or ODNR‑managed parcels, including:

•	Access parcels
•	Habitat management parcels
•	Hatchery parcels
•	Scenic River parcels
•	State Forests
•	State Nature Preserves
•	State Parks
•	State owned ecological parcels
•	Tailwaters parcels
•	Unnamed ODNR parcels
•	Wildlife Areas

**Required Fields (conceptual):**  
Division, OwnershipType, County, ODNR Lands Name, Calculated Acres, Geometry

**Query Pattern (conceptual):**  
Use the ArcGIS REST `query` operation on the ODNR Lands & Facilities layer with
filters for County, Division, and OwnershipType.

**Output:**  
Emit each parcel as a Site entity using standard fields.


---

### 3.2 STATE NATURE PRESERVES EXTRACTION

**Enumerative Source:**  
https://ohiodnr.gov/go-and-do/plan-a-visit/find-a-property/find-a-property-search?type=State%20Nature%20Preserve 

**Additional Sources:**  
- DNAP preserve pages  
- DNAP maps  
- DNAP GIS datasets (if published)

**Method:**  
- Enumerate preserves by county  
- Extract name, address, county, acres, description, access, URL  
- Include only parcels physically in the target county  


---

### 3.3 STATE PARKS EXTRACTION

**Enumerative Source:**  
https://ohiodnr.gov/go-and-do/plan-a-visit/find-a-property/find-a-property-search?type=State%20Park 

**Additional Sources:**  
- ODNR park pages  
- ODNR park maps  
- ODNR park GIS datasets (if published)

**Method:**  
- Enumerate parks by county  
- Extract name, address, county, acres, description, access, URL 
- Include satellite parcels and internal units  


---

### 3.4 STATE FORESTS EXTRACTION

**Enumerative Source:**  
https://ohiodnr.gov/go-and-do/plan-a-visit/find-a-property/find-a-property-search?type=State%20Forest 

**Additional Sources:**  
- ODNR forestry pages  
- ODNR forest maps  
- ODNR forestry GIS datasets (if published)

**Method:**  
- Enumerate forests by county  
- Extract name, address, county, acres, description, access, URL 
- Include satellite tracts and research areas  


---

### 3.5 STATE WILDLIFE AREAS EXTRACTION

**Enumerative Source:**  
https://ohiodnr.gov/go-and-do/plan-a-visit/find-a-property/find-a-property-search?type=State%20Wildlife%20Area

**Method:**  
- Enumerate Wildlife Areas by county  
- Extract name, address, county, acres, description, access, URL 
- Include named tracts and satellite units  

**Note:**  
Wildlife Production Areas (WPA) must be discovered via ODNR Lands & Facilities.


---

### 3.6 PUBLIC HUNTING AREAS EXTRACTION

**Enumerative Source:**  
  https://ohiodnr.gov/discover-and-learn/safety-conservation/about-ODNR/wildlife/documents-publications/hunting-area-maps  

**Method:**  
- Enumerate Public Hunting Areas by county  
- Extract name, address, county, acres, description, access, URL 
- Include named tracts and satellite units  


---

### 3.7 STATE FISHING AREAS EXTRACTION

**Enumerative Sources:**  
  https://ohiodnr.gov/discover-and-learn/safety-conservation/about-ODNR/wildlife/documents-publications/fishing-lake-maps  
  https://ohiodnr.gov/discover-and-learn/safety-conservation/about-ODNR/wildlife/documents-publications/river-stream-fishing-maps 
  
**Method:**  
- Enumerate State Fishing Areas by county  
- Extract name, address, county, acres, description, access, URL 
- Include named tracts and satellite units  


---

### 3.8 SCENIC RIVERS EXTRACTION

**Enumerative Source:**  
https://ohiodnr.gov/go-and-do/plan-a-visit/find-a-property/find-a-property-search?type=State%20Scenic%20River

**Sources:**  
- Scenic River program pages  
- Scenic River maps  
- Scenic River GIS datasets (if published)

**Method:**  
- Identify Scenic Rivers passing through the county  
- Extract designation, description, URL  
- Emit as Trail Networks or Site Networks 


---

### 3.9 STATE FISH HATCHERIES EXTRACTION

**Enumerative Source:**  
https://ohiodnr.gov/go-and-do/plan-a-visit/find-a-property/find-a-property-search?type=Fish%20Hatchery

**Sources:**  
- Scenic River program pages  
- Scenic River maps  
- Scenic River GIS datasets (if published)

**Method:**  
- Enumerate State Fish Hatcheries by county  
- Extract name, address, county, acres, description, access, URL 
- Include associated operational lands


---

### 3.10 STATE MEMORIALS & HISTORIC SITES EXTRACTION

**Primary Enumerative Source:**  
https://www.ohiohistory.org/visit/browse-historic-sites/

**Additional ODNR Historic Places Sources:**  
- Let’s Get Historic Sites  
  https://ohiodnr.gov/go-and-do/see-the-sights/historic-places/lets-get-historic-sites  
- New Deal Era Sites  
  https://ohiodnr.gov/go-and-do/see-the-sights/historic-places/new-deal-era-sites/new-deal-era-sites  

**Method:**  
- Enumerate OHC memorials, preserves, landscapes by county  
-- Extract name, address, county, acres, description, access, URL 
- Include ODNR Historic Places Sites  


---

### 3.11 ODOT EXTRACTION (SCENIC OVERLOOKS, BIKEWAYS, MITIGATION)

**Sources:**  
- ODOT GIS  
- ODOT bikeway datasets  
- ODOT project pages  

**Method:**  
- Extract scenic overlooks  
- Extract state‑managed bikeway corridors  
- Extract identity‑bearing mitigation lands  


---

### 3.12 ODOT REST AREAS EXTRACTION

**Enumerative Source:**  
https://www.transportation.ohio.gov/traveling/rest-areas

**Method:**  
- Extract rest areas by county 
- Extract name, address, county, acres, description, access, URL 
- Extract trail or bikeway connections as Trails or Access Points  


---

### 3.13 OTIC SERVICE PLAZAS EXTRACTION

**Enumerative Source:**  
https://www.ohioturnpike.org/travelers/service-plazas

**Method:**  
- Enumerate service plazas by county    
- Extract name, address, county, acres, description, access, URL 
- Extract trail or bikeway connections as Trails or Access Points  


---

### 3.14 EPA / DEFA EXTRACTION

3.14.1 Authoritative Spatial Enumerator (Primary EPA Source)
Ohio EPA Maps & Data Portal (ArcGIS Hub)

**Enumerative Source:**
https://epa.ohio.gov/wps/portal/gov/epa/maps/epa-maps

**Purpose:**
This is the only EPA/DEFA resource that may contain mappable, spatially enumerated features relevant to the Natural Areas database.

**Method:**
- Extract name, address, county, acres, description, access, URL 

Extract any identity‑bearing geographic entities, including but not limited to:
- restoration project sites
- watershed restoration or mitigation parcels
- surface water monitoring stations
- groundwater protection areas
- regulated land‑use zones
- emergency response sites
- environmental quality monitoring locations
- any spatial layer representing a discrete geographic feature

**Rules:**
- Treat each spatial feature with a name, ID, or location as a potential Site, Child Site, or Access Point, depending on context.
- If a feature represents a programmatic boundary (e.g., watershed, region), do not create a Site unless the layer explicitly identifies a discrete place.
- If a feature is ambiguous, record it with uncertainty metadata and allow the Resolution Engine to adjudicate.

3.14.2 Non‑Enumerative EPA/DEFA Pages (Informational Only)
The following URLs provide program descriptions but do not enumerate geographic sites and must not be used as discovery enumerators:
DEFA Division Page
https://epa.ohio.gov/wps/portal/gov/epa/divisions-and-offices/environmental-financial-assistance/defa
DEFA Reports & Data
https://epa.ohio.gov/wps/portal/gov/epa/divisions-and-offices/environmental-financial-assistance/reports-and-data
WRRSP Program Page
https://epa.ohio.gov/wps/portal/gov/epa/divisions-and-offices/environmental-financial-assistance/wrrsp
Rule:
Use these pages only to confirm program context, not to enumerate Sites.

3.14.3 Entity Creation Rules for EPA/DEFA‑Derived Features
Create entities when EPA spatial data identifies:
- a discrete, named restoration site
- a monitoring station with a fixed location
- a mitigation parcel or restoration parcel
- a state‑owned or state‑managed ecological feature
- any identity‑bearing geographic unit with coordinates
Do not create entities for:
- program descriptions
- funding areas
- administrative regions
- non‑spatial documents

3.14.4 Metadata Requirements
For each EPA/DEFA‑derived entity, record:
- full source URL(s)
- dataset name and layer name
- feature ID or attribute fields
- coordinates or geometry
- extraction method (spatial enumerator)
- uncertainty notes (if applicable)
- all counties mentioned or implied

3.14.5 Integration Notes
EPA/DEFA spatial features integrate into:
- State Tier (Tier 2)
- Resolution Engine v4.0 for ambiguity handling
- Normalization Engine v4.0 for naming and geometry
- Discovery Metadata Specification v4.0
- TSV Output Specification v4.0
EPA/DEFA does not override ODNR or OHC authority; it supplements them.


---

### 3.15 ODA EXTRACTION

The Ohio Department of Agriculture (ODA) does not maintain a unified public directory of state‑owned natural‑resource lands. Most ODA content is programmatic (agronomic services, food safety, animal health, plant health, farmland preservation) and does not enumerate geographic sites.
However, ODA does maintain two categories of resources that may contain identity‑bearing geographic entities relevant to the Natural Areas database:
- Farmland Preservation Easements (geographically anchored parcels)
- Plant Health & Invasive Species Management Sites (occasionally spatial)
This section defines the extraction rules for ODA‑related state lands.

3.15.1 Authoritative ODA Spatial Enumerator (Primary ODA Source)
Ohio Farmland Preservation Program — Easement Map

**Enumerator:**
https://agri.ohio.gov/programs/farmland-preservation-office/​farmland-preservation-easement-program

**Purpose:**
This is the only ODA resource that consistently exposes geographically anchored parcels with identity‑bearing attributes.

**Method:**
- Extract name, address, county, acres, description, access, URL 

Extract any identity‑bearing geographic entities, including:
- agricultural easement parcels
- preserved farmland parcels
- ODA‑held conservation easements
- ODA‑managed agricultural land units

**Examples:**  
Demonstration farms, conservation areas  

**Rules:**
- Treat each parcel as a potential Site if it has a name, ID, or unique identity.
- If the parcel is unnamed but has a unique easement ID, treat it as an identity‑bearing parcel.
- If the parcel is privately owned but publicly designated as preserved farmland, include it (per your Natural Areas rule that privately owned but designated lands are in‑scope).
- If the parcel is purely administrative (e.g., funding only), do not create a Site.

3.15.2 Secondary ODA Pages (Informational Only — Not Enumerators)
These pages describe programs but do not enumerate geographic sites and must not be used as discovery enumerators.
ODA Division of Farmland Preservation (Program Overview)
https://agri.ohio.gov/programs/farmland-preservation-office/​farmland-preservation
ODA Plant Health Division (Programmatic)
https://agri.ohio.gov/divisions/plant-health/​plant-health
ODA Invasive Species Program (Programmatic)
https://agri.ohio.gov/divisions/plant-health/invasive-pests/​invasive-pests
Rule:
Use these pages only to confirm program context, not to enumerate Sites.

3.15.3 Conditional Spatial Sources (Use Only If Spatial Data Is Present)
ODA occasionally publishes spatial or semi‑spatial content in the following areas:
Gypsy Moth / Spongy Moth Treatment Areas
https://agri.ohio.gov/divisions/plant-health/invasive-pests/​gypsy-moth-program
Asian Longhorned Beetle Quarantine Zones
https://agri.ohio.gov/divisions/plant-health/invasive-pests/​asian-longhorned-beetle
Emerald Ash Borer Information
https://agri.ohio.gov/divisions/plant-health/invasive-pests/​emerald-ash-borer
Rules:
- Only extract features if the page provides maps, shapefiles, coordinates, or explicitly named geographic units.
- Quarantine zones without discrete place‑level identity are not Sites.
- Treatment polygons without names are not Sites unless they correspond to a known preserve, forest, or park.

3.15.4 Entity Creation Rules for ODA‑Derived Features
Create entities when ODA data identifies:
- a discrete, named preserved farmland parcel
- an ODA‑held agricultural easement
- a geographically anchored conservation parcel
- a named treatment site or management area
- any identity‑bearing geographic unit with coordinates
Do not create entities for:
- program descriptions
- funding areas
- administrative regions
- statewide pest‑management zones without discrete place identity

3.15.5 Metadata Requirements
For each ODA‑derived entity, record:
- full source URL(s)
- easement ID or parcel ID (if applicable)
- dataset or map name
- coordinates or geometry
- extraction method (spatial enumerator or conditional spatial source)
- uncertainty notes (if applicable)
- all counties mentioned or implied

3.15.6 Integration Notes
ODA‑derived features integrate into:
- State Tier (Tier 2)
- Resolution Engine v4.0
- Normalization Engine v4.0
- Discovery Metadata Specification v4.0
- TSV Output Specification v4.0
ODA does not override ODNR or OHC authority; it supplements them.


---

### 3.16 NON‑AUTHORITATIVE CROSS‑REFERENCE SOURCES (ALLOWED)

These may confirm identity, access, boundaries, or naming, but **must not** be
used for enumerative sibling discovery.

**Allowed cross‑reference sources:**

- ONAPA Preserve Map  
  https://www.onapa.org/preserve-map.html  
- ONAPA Preserve List (2013 PDF)  
  https://www.onapa.org/uploads/5/5/0/4/55043087/nature_preserve_list_updated_02272013.pdf  
- Ohio.org Festivals & Events  
  https://ohio.org/festivals-and-events  
- Cardinal Collection (OHC)  
  https://hub.catalogit.app/the-cardinal-collection  
- Permits Index  
  https://ohiodnr.gov/discover-and-learn/safety-conservation/about-ODNR/wildlife/documents-publications/permits  


---

## 4. ENUMERATIVE DISCOVERY RULES

Tier 2 must enumerate all authoritative state‑level listing pages, including:

- ODNR Find‑a‑Property (all types)  
- Wildlife Map‑Index pages  
- Scenic Rivers  
- State Memorials (OHC)  
- Let’s Get Historic Sites  
- New Deal Era Sites  
- ODOT Rest Areas  
- OTIC Service Plazas  
- State‑managed easement listings  

Enumerative discovery must produce the complete sibling universe for Tier 2.


---

## 5. RECURSIVE DISCOVERY RULES

Tier 2 must recursively follow:

- `*.ohiodnr.gov`  
- `*.ohiohistory.org`  
- `*.transportation.ohio.gov`  
- `*.ohioturnpike.org`  
- `*.epa.ohio.gov` 
- `*.agri.ohio.gov`

Recursion extracts:

- Child Sites  
- Trails  
- Trail Segments  
- Access Points  
- Internal units  
- Maps  
- PDFs  
- Geometry  
- Metadata  

Recursion must stop when:

- Domain not on allowlist  
- Page is administrative or non‑recreational  
- Page does not contribute geographic entities  
- Page is a document index with no Sites  


---

## 6. ENTITY CREATION RULES

### 6.1 Site Creation
Create a Site when:

- State‑managed or state‑affiliated  
- Identity‑bearing  
- Public access or recreation relevance exists  

### 6.2 Child Site Creation
Create when:

- Named internal units exist  
- Campgrounds, day‑use areas, management units  
- Rest area or plaza sub‑units  

### 6.3 Trail Creation
Create a Trail when:

- A named trail appears in state datasets or maps  

### 6.4 Trail Segment Creation
Create a Trail Segment when:

- Segment‑level geometry or identifiers exist  

### 6.5 Trail Network Creation
Create a Trail Network when:

- A statewide or regional multi‑trail system exists  

### 6.6 Site Network Creation
Create a Site Network when:

- A Scenic River corridor or similar designation exists  

### 6.7 Access Point Creation
Create an Access Point when:

- A visitor‑facing entry location is documented  


---

## 7. METADATA REQUIREMENTS

Each entity must include:

- Full Discovery Metadata v4.0  
- All raw source references  
- All counties (raw)  
- All conflicts and uncertainties  
- All parent relationships  
- All geometry (if available)  

All values must be raw and unnormalized.


---

## 8. OUTPUT REQUIREMENTS

Each state entity must output a Raw Discovery Record conforming to:

- Discovery Output Specification v4.0  
- Discovery Metadata Specification v4.0  
- Schema Module v4.0  
- Vocabulary Module v4.0  


---

## 9. INTEGRATION POINTS

This module integrates with:

- Discovery Protocol Module v4.0  
- Discovery Orchestration Module v4.0  
- Tier Sub‑Procedure Template v4.0  
- All Entity Discovery Sub‑Procedures v4.0  
- Child Site Rules Module v4.0  
- Discovery Metadata Specification v4.0  
- Discovery Output Specification v4.0  
- Resolution Engine v4.0  
- Normalization Engine v4.0  
- TSV Output Specifications v4.0  
- County Baseline Module v4.0  


---

## 10. VERSIONING

- This module is **State Lands Discovery Sub‑Procedure v4.0**.  
- Updates to ODNR, OHC, ODOT, OTIC, EPA, or ODA datasets may result in v4.1+.  
- Any change to tier order or workflow must be made in the Discovery Protocol Module v4.0.  

---

# END OF STATE LANDS DISCOVERY SUB‑PROCEDURE v4.0