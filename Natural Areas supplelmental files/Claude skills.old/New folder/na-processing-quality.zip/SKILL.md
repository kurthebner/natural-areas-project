---
name: Natural Areas Processing & Quality Control
description: Orchestrate Natural Areas Project workflows including bootstrapping, processing, resolution, audit logging, and baseline management for data quality assurance
---

# Natural Areas Processing & Quality Control Skill

## Overview

This skill provides workflow orchestration, resolution engines, audit logging, and baseline management for Natural Areas Project operations. It ensures data flows correctly through the discovery → normalization → resolution → entity graph pipeline with full quality control and auditability.

Use this skill when managing Natural Areas Project workflows, resolving entity conflicts, establishing baselines, or conducting quality audits.

## When to Use This Skill

Trigger this skill when users request:
- "Set up a new county discovery project"
- "Bootstrap Natural Areas Project for [County]"
- "Resolve conflicts in discovery data"
- "Run entity resolution"
- "Process discovery results"
- "Audit data quality"
- "Create baseline for county"
- "Orchestrate the full pipeline"
- "Generate quality reports"

## Core Capabilities

### 1. Session Bootstrap

Initializes new discovery sessions:

**Bootstrap Process:**
1. **Environment Setup**
   - Load all v4.0 module specifications
   - Initialize schema definitions
   - Load controlled vocabularies
   - Configure normalization rules
   - Set up audit logging

2. **Target Configuration**
   - Define geographic scope (county, multi-county, state)
   - Set discovery tier sequence
   - Configure jurisdictional authorities
   - Establish baseline if available

3. **Resource Preparation**
   - Validate required tools available (web_search, web_fetch)
   - Set up output directories
   - Initialize logging framework
   - Configure quality thresholds

4. **Session Context**
   - Assign unique session identifier
   - Document session metadata
   - Set discovery start time
   - Initialize entity tracking

**Output:** Ready-to-run discovery session with all modules loaded and configured

### 2. Discovery Processing Orchestration

Manages the complete discovery workflow:

**Processing Pipeline:**

```
Raw Discovery → Resolution → Normalization → Entity Graph → TSV Output
```

**Phase 1: Raw Discovery Collection**
- Receive raw discovery records from discovery workflow
- Validate discovery metadata completeness
- Group records by entity type
- Track discovery provenance

**Phase 2: Entity Resolution**
- Detect potential duplicates across sources
- Apply resolution rules
- Merge confirmed duplicates
- Handle conflicts
- Document resolution decisions

**Phase 3: Normalization**
- Apply entity-specific normalization rules
- Standardize field values
- Validate against schemas
- Map to controlled vocabularies
- Generate normalized entities

**Phase 4: Entity Graph Construction**
- Build entity nodes
- Create relationship edges
- Validate graph structure
- Detect circular references
- Ensure referential integrity

**Phase 5: Output Generation**
- Generate TSV files
- Run integrity checks
- Produce quality reports
- Create audit logs

### 3. Entity Resolution Engine

Sophisticated duplicate detection and merging:

**Resolution Strategies:**

**Exact Match Resolution:**
- Same name, same county → likely duplicate
- Same coordinates (within 100m) → likely duplicate
- Same address → likely duplicate
- Multiple exact matches require review

**Fuzzy Match Resolution:**
- Similar names (Levenshtein distance)
- Near coordinates (within 500m)
- Similar descriptions
- Requires confidence threshold for auto-merge

**Multi-Source Resolution:**
- Same entity discovered from multiple tiers
- Authority hierarchy determines canonical values
  - State official source > County source > Municipal source
- Merge metadata from all sources
- Preserve all provenance

**Conflict Resolution:**
- Same entity, different values for fields
- Apply resolution rules:
  - Higher authority source wins
  - Most recent discovery wins (when authority equal)
  - More complete record wins
  - Flag unresolvable conflicts for manual review

**Resolution Documentation:**
- Log all merge decisions
- Document which sources merged
- Record conflict resolutions
- Maintain version history

### 4. County Baseline Management

Manages county-level baseline data:

**Baseline Purposes:**
- **Starting Point:** Known entities before discovery begins
- **Validation:** Expected entity counts by tier
- **Quality Check:** Compare discovered vs. expected
- **Completeness:** Calculate coverage percentages

**Baseline Components:**

**1. Jurisdictional Baseline**
- Complete list of municipalities (cities + villages)
- Complete list of townships
- Regional districts
- Special districts
- Land conservancies
- Major private land holders

**2. Entity Count Baseline**
- Expected number of state sites
- Expected number of county sites
- Known major trail systems
- Documented preserves

**3. Authority Baseline**
- List of managing authorities
- Jurisdiction boundaries
- Website URLs
- Contact information

**4. Historical Baseline**
- Previous discovery results
- Known changes since last discovery
- Closed/merged/renamed entities

**Baseline Usage:**
- Pre-discovery: Set expectations
- During discovery: Validate completeness
- Post-discovery: Calculate coverage
- Quality assurance: Identify gaps

### 5. Audit & Logging System

Comprehensive tracking and auditability:

**Audit Trail Components:**

**1. Discovery Audit Log**
- Session identifier
- Start/end timestamps
- Target geography
- Tiers searched
- Entities discovered per tier
- Sources accessed
- Tools used
- Errors encountered

**2. Resolution Audit Log**
- Entities evaluated for duplication
- Merge decisions made
- Conflicts detected
- Resolution strategies applied
- Manual review flags

**3. Normalization Audit Log**
- Raw values before normalization
- Applied transformations
- Validation results
- Vocabulary mappings
- Failed validations

**4. Processing Audit Log**
- Pipeline stage transitions
- Entity counts at each stage
- Quality metrics
- Performance metrics
- Errors and warnings

**5. Output Audit Log**
- Files generated
- Record counts
- Integrity check results
- Export timestamps
- File checksums

**Audit Reports:**
- Session summary report
- Quality metrics report
- Coverage analysis report
- Issue/warning report
- Performance report

### 6. Quality Assurance Framework

Multi-level quality validation:

**Tier 1: Discovery Quality**
- Completeness per tier (% entities searched)
- Source documentation rate
- Coverage confidence level
- Missing entity detection

**Tier 2: Data Quality**
- Required field completeness
- Format validation pass rate
- Vocabulary compliance rate
- Coordinate validity rate
- Contact information validity

**Tier 3: Relationship Quality**
- Referential integrity pass rate
- Orphaned entity detection
- Circular reference detection
- Network consistency

**Tier 4: Resolution Quality**
- Duplicate detection effectiveness
- Merge accuracy
- Conflict resolution rate
- Manual review queue size

**Tier 5: Output Quality**
- TSV integrity pass rate
- Cross-file consistency
- Character encoding compliance
- File size reasonableness

**Quality Metrics Dashboard:**
```
Discovery Completeness: 96%
  - State Tier: 100%
  - County Tier: 100%
  - Municipal Tier: 94% (3 of 18 municipalities pending)
  - Private Tier: 85% (requires additional research)

Data Quality: 97%
  - Required Fields: 100%
  - Format Validation: 96%
  - Vocabulary Compliance: 98%
  - Coordinates: 94%

Resolution Quality: 99%
  - Duplicates Resolved: 12 merged
  - Conflicts: 2 flagged for review
  - Confidence: High

Output Quality: 100%
  - TSV Integrity: PASS
  - Referential Integrity: PASS
  - File Structure: PASS
```

## Workflow Orchestration

### Complete Pipeline Execution

**User request:** "Process Wood County discovery results"

**Orchestration sequence:**

```
1. BOOTSTRAP
   ✓ Load v4.0 modules
   ✓ Initialize Wood County session
   ✓ Load baseline data
   ✓ Configure audit logging

2. PROCESS RAW DISCOVERY
   ✓ Ingest 64 raw discovery records
   ✓ Parse discovery metadata
   ✓ Validate provenance

3. ENTITY RESOLUTION
   ✓ Detect 3 potential duplicates
   ✓ Merge 2 confirmed duplicates
   ✓ Flag 1 for manual review
   ✓ Result: 62 unique entities

4. NORMALIZATION
   ✓ Normalize 62 entities
   ✓ Apply vocabulary mappings
   ✓ Validate against schemas
   ✓ Result: 62 normalized entities

5. ENTITY GRAPH BUILD
   ✓ Create 62 entity nodes
   ✓ Create 47 relationship edges
   ✓ Validate graph structure
   ✓ Result: Valid entity graph

6. OUTPUT GENERATION
   ✓ Generate Sites.tsv (44 rows)
   ✓ Generate Trails.tsv (18 rows)
   ✓ Run integrity checks
   ✓ Result: 6 TSV files ready

7. QUALITY ASSURANCE
   ✓ Run quality validation
   ✓ Generate quality report
   ✓ Calculate coverage: 96%
   ✓ Result: Quality targets met

8. AUDIT LOG
   ✓ Generate session report
   ✓ Document all decisions
   ✓ Archive audit trail
   ✓ Result: Complete audit log
```

## Reference Documentation

The skill includes 9 processing and quality control modules:

### Workflow Modules (5)
- Natural Areas Project Overview v4.0
- Bootstrap Module v4.0
- Processing Module v4.0
- Resolution Module v4.0
- Resolution Engine v4.0

### Quality Control Modules (2)
- Audit and Logging Module v4.0
- County Baseline Module v4.0

### Coordination Modules (2)
- Module Manifest v4.0
- Discovery Architecture v4.0 (for reference)

See the `references/` directories for complete module documentation.

## Example Usage: New County Setup

**User:** "Set up Natural Areas Project for Franklin County, Ohio"

**Claude executes:**

```
BOOTSTRAP: Franklin County, Ohio

1. JURISDICTIONAL RESEARCH
   - Municipalities: 15 cities + 14 townships
   - County: Franklin County
   - State: Ohio
   - Special Districts: Metro Parks (regional)

2. BASELINE ESTABLISHMENT
   Known Entities (from previous data):
   - State: 1 state forest, 2 wildlife areas
   - County: 19 Metro Parks sites
   - Municipal: ~25 estimated
   - Private: 3-5 estimated
   
   Expected Total: 50-60 entities

3. MODULE CONFIGURATION
   ✓ Loaded schema modules (9)
   ✓ Loaded vocabulary modules (6)
   ✓ Loaded normalization modules (8)
   ✓ Loaded discovery modules (18)
   ✓ Loaded output modules (7)

4. SESSION INITIALIZATION
   Session ID: FC-OH-20260212-001
   Start Time: 2026-02-12 14:30:00
   Target: Franklin County, Ohio
   Scope: All tiers (1-8)
   
   Audit Log: ENABLED
   Quality Thresholds: Set to v4.0 standards
   
5. READY FOR DISCOVERY
   Next step: Begin Tier 1 (State) discovery
```

## Integration with Other Skills

This skill works with:
- **Discovery Workflow Skill:** Receives raw discovery output
- **Schema & Vocabulary Skill:** Uses schemas for validation
- **Normalization & Output Skill:** Orchestrates normalization and output
- **All Skills:** Provides bootstrap, audit, and quality control framework

## Resolution Engine Example

**Scenario:** Same park discovered from multiple sources

```
RAW DISCOVERIES:

Source 1 (County Website):
- Name: "Scioto Grove Metro Park"
- Type: County Park
- Acreage: 621
- Address: 5000 Stonebridge Blvd, Grove City, OH
- Coordinates: 39.8742, -83.0931
- Source Authority: County Park District (HIGH)

Source 2 (Municipal Website):
- Name: "Scioto Grove Metropark"
- Type: Metro Park
- Acreage: Not specified
- Address: Grove City, Ohio
- Coordinates: Not specified
- Source Authority: Municipality (MEDIUM)

Source 3 (State Database):
- Name: "Scioto Grove Park"
- Type: Regional Park
- Acreage: 620 acres
- Address: Not specified
- Coordinates: 39.874, -83.093
- Source Authority: State Registration (MEDIUM)

RESOLUTION ENGINE:

1. DUPLICATE DETECTION
   ✓ Names are similar (fuzzy match: 95%)
   ✓ Coordinates match (within 100m)
   ✓ Same county
   → CONFIRMED DUPLICATE

2. MERGE STRATEGY
   Canonical Values (Authority-based):
   - Name: "Scioto Grove Metro Park" (Source 1, highest authority)
   - Type: "County Park" (Source 1)
   - Acreage: 621 (Source 1, most specific)
   - Address: "5000 Stonebridge Blvd, Grove City, OH" (Source 1)
   - Coordinates: 39.8742, -83.0931 (Source 1, most precise)

3. PROVENANCE PRESERVATION
   Merged Entity Metadata:
   - Primary Source: Franklin County Metro Parks
   - Supporting Sources: Grove City, Ohio State Parks Database
   - Merge Date: 2026-02-12
   - Confidence: HIGH

4. RESULT
   Single canonical entity with complete provenance
```

## Key Principles

1. **Orchestration Not Execution:** Coordinates workflow, doesn't replace other skills
2. **Quality First:** Every stage has quality gates
3. **Full Auditability:** All decisions logged and traceable
4. **Baseline Validation:** Always compare to expected results
5. **Resolution Before Output:** Clean data before export
6. **Documentation Always:** Every session fully documented

## Notes

**Session Management:**
- Each county discovery is a session
- Sessions are independent and traceable
- Session IDs format: `{County}-{State}-{Date}-{Sequence}`

**Quality Philosophy:**
- Better to flag for review than auto-fix incorrectly
- Manual review queue is normal and expected
- 95%+ automated processing is target
- 100% auditability is requirement

**Performance Considerations:**
- Bootstrap is one-time per session
- Processing scales to thousands of entities
- Resolution engine optimized for batch operation
- Audit logging is asynchronous

---

**Version:** 4.0  
**Last Updated:** February 2026  
**Module Count:** 9 workflow and quality control modules
