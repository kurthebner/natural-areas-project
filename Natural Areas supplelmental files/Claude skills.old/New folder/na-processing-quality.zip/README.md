# Natural Areas Processing & Quality Control Skill

## Overview
Workflow orchestration, resolution engines, audit logging, and baseline management for Natural Areas projects.

## Module Count
9 modules (5 workflow + 2 quality + 2 reference)

## Key Features
- Session bootstrap and initialization
- Discovery processing orchestration
- Entity resolution engine
- County baseline management
- Comprehensive audit logging
- Multi-tier quality validation

## When to Use
- Setting up new county projects
- Orchestrating complete workflows
- Resolving entity conflicts
- Conducting quality audits
- Managing baselines

## Capabilities
- Pipeline orchestration
- Duplicate detection and merging
- Conflict resolution
- Quality metrics dashboard
- Session management
- Audit trail generation

## Version
v4.0 - February 2026

## Part of
Natural Areas Project Complete System
