---
name: Natural Areas Discovery Workflow
description: Execute systematic discovery of natural areas, parks, trails, and preserves across jurisdictions using tier-based methodology with web search and data extraction
---

# Natural Areas Discovery Workflow Skill

## Overview

This skill enables Claude to conduct comprehensive, systematic discovery of natural areas across any U.S. county following the Natural Areas Project v4.0 methodology. Use this skill when the user requests discovery, cataloging, or research of parks, trails, natural preserves, or outdoor recreation areas within a specific geographic area.

The skill implements a rigorous **tier-based discovery system** that ensures 95%+ completeness through exhaustive, systematic searching across eight jurisdictional tiers, from state and federal lands down to private preserves.

## When to Use This Skill

Trigger this skill when users request:
- "Discover all parks in [County/Region]"
- "Catalog natural areas in [Location]"
- "Find trails and outdoor spaces in [Area]"
- "Create inventory of recreation sites"
- "Research parks and preserves systematically"
- Any county-level or regional natural areas discovery project

## Core Capabilities

### 1. Tier-Based Discovery System
Systematic discovery across 8 jurisdictional tiers:
- **Tier 1:** State Parks, Forests, Wildlife Areas
- **Tier 2:** Federal Parks, Forests, Refuges, Tribal Lands
- **Tier 3:** County Park Districts
- **Tier 4:** Regional Park Districts
- **Tier 5:** Township Parks
- **Tier 6:** Municipal Parks (Cities and Villages)
- **Tier 7:** Conservancy Preserves (Land Trusts, Nature Conservancy)
- **Tier 8:** Private Preserves (Universities, Foundations, Private Organizations)

### 2. Entity Discovery
Discovers six types of entities following the v4.0 ontology:
- **Sites:** Parks, preserves, forests, wildlife areas
- **Trails:** Named trails within sites
- **Trail Segments:** Distinct sections of trails
- **Trail Networks:** Multi-trail systems
- **Site Networks:** Multi-site systems
- **Access Points:** Parking areas, trailheads, entrances

### 3. Discovery Methodology
Implements proven systematic approach:
- **Exhaustive over Efficient:** Search every entity, no assumptions
- **Fetch over Search:** Always retrieve official pages, never rely on snippets
- **Extract Everything:** Read complete pages, verify counts
- **Document Everything:** Record sources, methods, dates
- **100% Entity Coverage:** Complete each tier before advancing

## Critical Success Factors

### The Three Commandments of Discovery
1. **SYSTEMATIC BEATS SMART**
   - Check every entity, even if unlikely
   - Follow the process, don't optimize prematurely
   - Never skip based on size, population, or assumptions

2. **FETCH BEATS SEARCH**
   - Get actual pages, don't trust snippets
   - Read entire content, not just headers
   - Use web_fetch tool for all official pages

3. **DOCUMENT BEATS REMEMBER**
   - Record what you find AND don't find
   - Include sources, dates, methods
   - Document negative results with evidence

### Common Discovery Failures to Avoid
❌ Skipping small villages (they often have parks)
❌ Relying on search snippets instead of fetching pages
❌ Stopping at "good enough" completeness
❌ Making assumptions about entity size or likelihood
❌ Missing entities listed on pages (extract ALL, not just first)

## Discovery Workflow

### Phase 1: Preparation
1. Identify target county/region
2. Research jurisdictional structure:
   - List all municipalities (cities + villages)
   - List all townships
   - Identify relevant districts
3. Set up documentation framework
4. Review baseline data if available

### Phase 2: Tier-by-Tier Execution
For each tier (1-8):
1. **Enumerate entities:** Create complete list before searching
2. **Systematic search:** Search EACH entity individually
3. **Fetch official pages:** Use web_fetch on government/official sites
4. **Extract all sub-entities:** Parse complete content
5. **Verify counts:** Ensure extracted count matches claims
6. **Document findings:** Record sources and methods
7. **Mark complete:** Only after 100% verification

### Phase 3: Entity-Specific Discovery
For each discovered site:
1. Discover associated trails
2. Discover trail segments
3. Discover access points
4. Identify network memberships
5. Document relationships

### Phase 4: Quality Verification
1. Cross-reference discoveries across tiers
2. Verify no missing entities mentioned in sources
3. Check count reconciliation
4. Review documentation completeness
5. Calculate coverage percentage

## Output Format

Discovery outputs Raw Discovery Records containing:
- Entity identifiers
- Entity type
- Discovery tier
- Jurisdictional authority
- Geographic data
- Source provenance
- Discovery metadata
- Relationship information

Formatted as TSV files following NA Project specifications.

## Reference Documentation

The skill includes complete reference to 18 discovery modules:

### Core Protocol Modules (4)
- Discovery Protocol v4.0
- Discovery Orchestration v4.0
- Discovery Metadata Specification v4.0
- Discovery Output Specification v4.0

### Jurisdictional Sub-Procedures (8)
- County Discovery
- Municipal Discovery
- Township Discovery
- State Discovery
- Federal/Tribal Discovery
- District Discovery
- Private Discovery
- Conservancy Discovery

### Entity-Specific Sub-Procedures (6)
- Site Discovery
- Trail Discovery
- Trail Segment Discovery
- Trail Network Discovery
- Site Network Discovery
- Access Point Discovery

### Best Practices Reference
- Improved Discovery Methodology (lessons learned)

See the `references/` directory for complete module documentation.

## Example Usage

**User:** "Discover all parks and trails in Wood County, Ohio"

**Claude executes:**
1. Enumerates 18 municipalities in Wood County
2. Tier 1: Searches Ohio DNR for state facilities
3. Tier 2: Searches federal land databases
4. Tier 3: Fetches Wood County Park District website
5. Tier 4: Searches for regional districts
6. Tier 5: Searches all 19 townships systematically
7. Tier 6: Searches ALL 18 municipalities (3 cities + 15 villages)
   - For each: fetches official website, parks page
   - Extracts all parks (even from small villages like Luckey)
8. Tier 7: Searches land trusts, conservancies
9. Tier 8: Searches universities, private foundations
10. For each site: discovers trails, access points, relationships
11. Outputs comprehensive TSV with 95%+ completeness

## Quality Metrics

Success indicators:
- ✅ 100% entity coverage per tier
- ✅ All findings have documented sources
- ✅ Counts match claims (plurals verified)
- ✅ No cross-reference gaps
- ✅ Negative results documented with evidence
- ✅ 95%+ estimated completeness

## Dependencies

Required tools:
- `web_search` - For finding official websites and databases
- `web_fetch` - For retrieving complete page content (CRITICAL)
- File creation capabilities - For TSV output

## Notes

This skill implements lessons learned from real discovery projects, particularly the Wood County, Ohio project where initial methodology missed 3+ parks in small villages by not systematically searching each municipality and not fetching official pages.

The methodology prioritizes **completeness over efficiency** - spending the time to achieve 95%+ coverage is more valuable than quick but incomplete results.

---

**Version:** 4.0  
**Last Updated:** February 2026  
**Module Count:** 18 discovery modules + methodology
