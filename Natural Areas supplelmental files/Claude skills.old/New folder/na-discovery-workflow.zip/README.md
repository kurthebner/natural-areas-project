# Natural Areas Discovery Workflow Skill

## Overview
Systematic tier-based discovery of natural areas, parks, trails, and preserves across jurisdictions.

## Module Count
18 discovery modules + best practices guide

## Key Features
- 8-tier jurisdictional discovery system
- Systematic, exhaustive methodology
- Web search and fetch-based extraction
- 95%+ completeness target
- Full provenance documentation

## When to Use
- Discovering parks and trails in a county or region
- Systematic natural areas cataloging
- Quality-controlled discovery projects

## Components
- Core Protocol Modules (4)
- Jurisdictional Sub-Procedures (8)
- Entity-Specific Sub-Procedures (6)
- Best Practices Guide (1)

## Version
v4.0 - February 2026

## Part of
Natural Areas Project Complete System
