---
name: Natural Areas Normalization & Output
description: Normalize raw discovery data and generate TSV output files following Natural Areas Project v4.0 specifications with data quality validation
---

# Natural Areas Normalization & Output Skill

## Overview

This skill transforms raw discovery data into clean, normalized entities and produces standardized TSV (tab-separated values) output files following Natural Areas Project v4.0 specifications.

Use this skill when you need to process discovered natural areas data, apply normalization rules, validate data quality, and generate formatted output files ready for database import or analysis.

## When to Use This Skill

Trigger this skill when users request:
- "Normalize this natural areas data"
- "Generate TSV output from discovery results"
- "Clean and standardize this parks data"
- "Create entity records from raw data"
- "Validate data quality"
- "Apply normalization rules"
- "Export to TSV format"
- "Prepare data for database import"

## Core Capabilities

### 1. Entity Normalization Engine

Applies comprehensive normalization rules for all six entity types:

**Site Normalization:**
- Standardize site names (remove prefixes like "The", normalize suffixes)
- Classify site types using controlled vocabulary
- Normalize ownership and jurisdiction values
- Parse and validate geographic coordinates
- Standardize address formats
- Clean and validate contact information
- Extract and format amenities lists
- Handle parent-child site relationships

**Trail Normalization:**
- Standardize trail names and types
- Normalize trail difficulty classifications
- Convert length units to miles
- Standardize surface type descriptions
- Classify trail configurations (loop vs. out-and-back)
- Validate and clean elevation data
- Normalize trail blaze colors

**Access Point Normalization:**
- Standardize access point types
- Normalize parking capacity representations
- Clean address and location data
- Validate coordinate formats
- Standardize amenity descriptions

**Trail Segment Normalization:**
- Normalize segment identifiers
- Validate endpoint coordinates
- Standardize surface types
- Clean segment descriptions

**Trail Network Normalization:**
- Standardize network names
- Validate member trail references
- Normalize network types
- Clean descriptions

**Site Network Normalization:**
- Standardize network names (e.g., "Ohio State Parks System")
- Validate member site references
- Normalize governing authorities
- Clean descriptions and URLs

### 2. Normalization Rules Engine

Executes transformation rules:

**String Normalization:**
- Trim whitespace
- Standardize capitalization (title case for names)
- Remove redundant words
- Fix common misspellings
- Normalize punctuation
- Handle NULL/empty values

**Geographic Normalization:**
- Validate coordinate formats (decimal degrees)
- Standardize coordinate precision
- Validate coordinate ranges
- Convert DMS to decimal if needed
- Validate county/state combinations

**Enumerated Value Normalization:**
- Map variations to standard vocabulary
  - "Mtn Bike Trail" → "Mountain Biking"
  - "Easy/Moderate" → "Moderate"
  - "County Park" vs "Park District" → standardized
- Handle synonyms and abbreviations
- Flag unknown/invalid values for review

**Relationship Normalization:**
- Validate entity ID references
- Clean foreign key relationships
- Handle circular references
- Resolve ambiguous parent-child relationships

**Unit Normalization:**
- Convert acres to standard format
- Standardize miles/kilometers
- Normalize elevation units (feet)
- Handle mixed unit systems

### 3. Entity Upsert Engine

Manages entity creation and updates:

**Identity Resolution:**
- Detect duplicate entities across sources
- Merge entities based on matching criteria
- Preserve provenance from all sources
- Handle conflicts in merged data
- Maintain entity version history

**Upsert Logic:**
- INSERT new entities not in system
- UPDATE existing entities with new data
- MERGE when same entity found from multiple sources
- Track which fields came from which sources
- Preserve metadata about changes

**Conflict Resolution:**
- Highest-authority source wins
- Most recent discovery preferred when authority equal
- Flag conflicts for manual review when appropriate
- Document resolution decisions

### 4. TSV Output Specifications

Generates six standardized TSV files:

**1. Sites.tsv**
- One row per site entity
- All site schema fields in defined column order
- Tab-delimited format
- Header row with field names
- UTF-8 encoding
- Proper handling of special characters in content

**2. Trails.tsv**
- One row per trail entity
- Complete trail schema fields
- Relationship references (Site_ID, Trail_Network_ID)

**3. Trail_Segments.tsv**
- One row per trail segment
- Segment schema with parent trail reference
- Geographic coordinate pairs

**4. Trail_Networks.tsv**
- One row per trail network
- Member trail references
- Network-level attributes

**5. Site_Networks.tsv**
- One row per site network
- Member site references
- Network governance information

**6. Access_Points.tsv**
- One row per access point
- Site and trail associations
- Facility information

### 5. Data Quality Validation

Performs comprehensive quality checks:

**Required Field Validation:**
- All required fields present
- No NULL values in required fields
- Proper data types for all fields

**Format Validation:**
- Dates in ISO 8601 format (YYYY-MM-DD)
- Coordinates in decimal degrees
- Phone numbers standardized
- URLs properly formatted
- Email addresses validated

**Referential Integrity:**
- All Site_IDs referenced by trails exist
- All Trail_IDs referenced by segments exist
- All Parent_Site_IDs reference valid sites
- All network membership references valid

**Vocabulary Compliance:**
- All enumerated fields use valid values
- Unknown values flagged
- Suggestions provided for near-matches

**Cross-Field Validation:**
- County/State combinations valid
- Acreage reasonable for site type
- Coordinates within expected bounds
- Trail length reasonable for configuration

**Duplicate Detection:**
- Same-name entities in same county
- Near-duplicate names (fuzzy matching)
- Identical coordinates
- Similar descriptions

### 6. TSV Integrity Check

Final validation before output:

**File Structure Validation:**
- Correct number of columns in each row
- Proper tab delimiting
- No embedded tabs in content
- UTF-8 encoding compliance
- Line ending consistency

**Header Validation:**
- Headers match schema specifications
- Column order correct
- All required columns present

**Content Validation:**
- No orphaned references
- Row counts match entity counts
- Cross-file consistency
- Primary key uniqueness

**Output Completeness:**
- All discovered entities represented
- All relationships captured
- Metadata preserved
- Provenance documented

## Normalization Workflow

### Phase 1: Raw Data Ingestion
1. Load raw discovery records
2. Parse discovery metadata
3. Identify entity types
4. Group by entity

### Phase 2: Entity-Level Normalization
For each entity type:
1. Apply string normalization rules
2. Apply vocabulary mapping
3. Normalize geographic data
4. Normalize relationships
5. Validate against schema

### Phase 3: Cross-Entity Resolution
1. Detect duplicate entities
2. Resolve identity conflicts
3. Merge entity data
4. Build relationship graph
5. Validate referential integrity

### Phase 4: Quality Validation
1. Run required field checks
2. Run format validation
3. Run vocabulary compliance checks
4. Run cross-field validation
5. Run duplicate detection
6. Generate quality report

### Phase 5: TSV Generation
1. Sort entities by ID
2. Format fields per TSV specs
3. Generate headers
4. Write entity rows
5. Run integrity checks
6. Output files

### Phase 6: Quality Assurance
1. Validate file structure
2. Verify row/entity counts
3. Check cross-file references
4. Generate summary statistics
5. Document any issues

## Reference Documentation

The skill includes 15 normalization and output modules:

### Normalization Modules (8)
- Site Normalization v4.0
- Access Point Normalization v4.0
- Trail Normalization v4.0
- Trail Segment Normalization v4.0
- Trail Network Normalization v4.0
- Site Network Normalization v4.0
- Normalization Engine v4.0
- Entity Upsert Engine v4.0

### Output Specification Modules (7)
- Site TSV Specifications v4.0
- Access Point TSV Specifications v4.0
- Trail TSV Specifications v4.0
- Trail Segment TSV Specifications v4.0
- Trail Network TSV Specifications v4.0
- Site Network TSV Specifications v4.0
- TSV Integrity Check v4.0

See the `references/` directories for complete module documentation.

## Example Usage

**User:** "Normalize this raw site data and generate TSV output"

**Claude executes using this skill:**

```
Processing raw discovery data...

NORMALIZATION:
✓ Standardized 47 site names
✓ Mapped 8 site type variations to controlled vocabulary
✓ Normalized 23 address formats
✓ Validated 41 coordinate pairs
✓ Resolved 3 duplicate sites across sources
✓ Applied parent-child relationships to 5 sites

VALIDATION:
✓ All required fields present
✓ Geographic coordinates valid
✓ Vocabulary compliance: 100%
✓ Referential integrity: 2 warnings (documented)
✓ Duplicate detection: 0 duplicates after merge

TSV OUTPUT:
✓ Sites.tsv: 44 rows (47 discovered - 3 merged)
✓ Trails.tsv: 67 rows
✓ Trail_Segments.tsv: 143 rows
✓ Access_Points.tsv: 89 rows
✓ Trail_Networks.tsv: 4 rows
✓ Site_Networks.tsv: 3 rows

INTEGRITY CHECK:
✓ All files pass validation
✓ Cross-file references valid
✓ UTF-8 encoding verified
✓ Column counts correct

Files ready for database import.
```

## Normalization Examples

### Site Name Normalization
```
Raw: "The Metroparks of Butler County - Four Mile Creek Park"
Normalized: "Four Mile Creek Park"
Network: "Metroparks of Butler County" (extracted to Site_Network)

Raw: "WILDWOOD PRESERVE METROPARK"
Normalized: "Wildwood Preserve Metropark"

Raw: "Ft. Meigs State Memorial"
Normalized: "Fort Meigs State Memorial"
```

### Site Type Vocabulary Mapping
```
Raw: "County Metro Park"
Mapped: "County Park"

Raw: "State Nature Pres."
Mapped: "State Nature Preserve"

Raw: "Local Park"
Mapped: "Municipal Park" (with context from jurisdiction)
```

### Coordinate Normalization
```
Raw: "41° 23' 45\" N, 83° 37' 12\" W"
Normalized: 41.395833, -83.620000

Raw: "41.395833°, -83.620000°"
Normalized: 41.395833, -83.620000

Invalid: "41.395833, 83.620000" (missing negative longitude)
→ Flagged for review
```

### Trail Difficulty Normalization
```
Raw: "Easy to Moderate"
Normalized: "Moderate"

Raw: "Family Friendly"
Normalized: "Easy"

Raw: "Advanced"
Normalized: "Difficult"
```

## Output Format Specification

### TSV File Structure
```
[Header Row]
Field1	Field2	Field3	...	FieldN

[Data Rows]
Value1	Value2	Value3	...	ValueN
Value1	Value2	Value3	...	ValueN
...
```

### Field Formatting Rules
- **Text Fields:** Plain text, no quotes unless contain tabs/newlines
- **Numeric Fields:** No thousands separators, period for decimal
- **Date Fields:** YYYY-MM-DD format
- **Coordinate Fields:** Decimal degrees, 6 decimal precision
- **List Fields:** Comma-separated within field
- **NULL Values:** Empty string (two consecutive tabs)
- **Special Characters:** UTF-8 encoded, tabs/newlines escaped

### File Naming Convention
```
{Entity_Type}.tsv
Examples:
- Sites.tsv
- Trails.tsv
- Trail_Segments.tsv
- Trail_Networks.tsv
- Site_Networks.tsv
- Access_Points.tsv
```

## Integration with Other Skills

This skill works with:
- **Discovery Workflow Skill:** Receives raw discovery data as input
- **Schema & Vocabulary Skill:** Uses schemas and vocabularies for validation
- **Processing Skill:** Provides normalized entities for resolution and graph building

## Data Quality Metrics

Quality indicators tracked:
- **Completeness:** % of required fields populated
- **Accuracy:** % passing format validation
- **Consistency:** % matching controlled vocabularies
- **Integrity:** % passing referential integrity checks
- **Uniqueness:** Duplicate detection rate
- **Provenance:** % with documented sources

Target quality levels:
- Required field completeness: 100%
- Vocabulary compliance: 95%+
- Format validation pass rate: 98%+
- Referential integrity: 99%+

## Key Principles

1. **Preserve Provenance:** Never lose source information during normalization
2. **Deterministic Rules:** Same input always produces same output
3. **Authority Hierarchy:** Higher authority sources override lower
4. **Validation Before Output:** Catch errors before TSV generation
5. **Metadata Preservation:** Maintain discovery metadata through pipeline
6. **Auditability:** All transformations documented and traceable

## Notes

**Normalization vs. Enrichment:**
- Normalization standardizes existing data
- Does NOT add new information beyond mappings
- External enrichment (geocoding, etc.) is separate process

**Entity Identity:**
- Identity determined during normalization
- Based on name, location, and source authority
- Duplicates merged, conflicts documented

**Performance Considerations:**
- Normalization can handle 1000s of entities
- Entity upsert engine optimized for batch processing
- TSV generation is final step, not incremental

---

**Version:** 4.0  
**Last Updated:** February 2026  
**Module Count:** 15 normalization and output modules
