# Natural Areas Normalization & Output Skill

## Overview
Transform raw discovery data into clean, normalized entities and generate standardized TSV output files.

## Module Count
15 modules (8 normalization + 7 output specifications)

## Key Features
- Comprehensive normalization rules for all entity types
- Entity resolution and duplicate detection
- Controlled vocabulary mapping
- TSV output specifications
- Data quality validation
- Integrity checking

## When to Use
- Normalizing discovered data
- Generating TSV exports
- Validating data quality
- Preparing database imports

## Capabilities
- String normalization
- Geographic data standardization
- Enumerated value mapping
- Entity upsert and merging
- Six-file TSV output
- Referential integrity validation

## Version
v4.0 - February 2026

## Part of
Natural Areas Project Complete System
