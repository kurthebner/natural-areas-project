# Natural Areas Complete System - Mega-Skill

## Overview
**Complete end-to-end Natural Areas Project v4.0 system** with all 47 authoritative modules for discovering, cataloging, normalizing, and managing natural areas data.

## Module Count
47 active v4.0 modules + 1 best practices guide

## System Architecture
- **Six-Entity Ontology:** Sites, Trails, Segments, Networks, Access Points
- **Eight-Tier Discovery:** State through Private jurisdictions
- **Four-Stage Pipeline:** Discovery → Resolution → Normalization → Output
- **Complete Quality Control:** Audit, validation, baseline management

## When to Use
- **Complete county/regional projects:** End-to-end discovery and data production
- **Complex multi-jurisdiction work:** Coordinated discovery across areas
- **Training and reference:** Full system documentation
- **Quality-controlled outputs:** High-accuracy, auditable results

## Module Breakdown
- Schema Modules: 9
- Vocabulary Modules: 6
- Normalization Modules: 8
- Discovery Modules: 18
- Output Modules: 7
- Workflow Modules: 5
- Quality Control: 2
- Manifest & Best Practices: 2

## Key Capabilities
✅ Systematic 8-tier discovery  
✅ 6 entity types with full schemas  
✅ Controlled vocabularies  
✅ Entity resolution & duplicate detection  
✅ Comprehensive normalization  
✅ TSV output generation  
✅ Quality validation at every stage  
✅ Full audit trails  
✅ Baseline management  

## Quality Targets
- Geographic coverage: 95%+
- Data quality: 98%+
- Referential integrity: 99%+
- TSV integrity: 100%

## Version
v4.0 - February 2026

## Use Cases
✅ County-wide natural areas cataloging  
✅ Multi-county regional projects  
✅ Statewide system development  
✅ Quality-controlled data production  
✅ Baseline establishment  
✅ System training and reference  

## Alternative Options
For focused tasks, consider the modular skills:
- **Discovery only:** Use "Natural Areas Discovery Workflow"
- **Schema reference:** Use "Natural Areas Schema & Vocabulary"
- **Normalization:** Use "Natural Areas Normalization & Output"
- **Processing/QA:** Use "Natural Areas Processing & Quality Control"

## Notes
This mega-skill represents years of methodology development and real-world testing across Ohio counties. It implements lessons learned from actual discovery projects to achieve 95%+ completeness with full quality control and auditability.

Designed for systematic, comprehensive natural areas cataloging at any scale from single counties to statewide systems.
