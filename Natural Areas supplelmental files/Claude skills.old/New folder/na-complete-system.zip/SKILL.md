---
name: Natural Areas Complete System
description: Complete Natural Areas Project v4.0 system for discovering, cataloging, normalizing, and managing natural areas data across all U.S. jurisdictions with full quality control
---

# Natural Areas Complete System - Mega-Skill

## Overview

This is the **complete, comprehensive Natural Areas Project v4.0 system** containing all 47 authoritative modules organized into a unified, end-to-end workflow for discovering, cataloging, normalizing, and managing natural areas across the United States.

This mega-skill combines discovery workflows, entity schemas, controlled vocabularies, normalization rules, output specifications, processing orchestration, and quality control into a single integrated system.

## When to Use This Skill

Use this complete system when you need:
- **Full-stack natural areas projects:** End-to-end discovery through output
- **Complete county/regional cataloging:** Comprehensive discovery and data management
- **Complex multi-jurisdiction projects:** Coordinated discovery across multiple areas
- **Quality-controlled data production:** High-accuracy, auditable outputs
- **Baseline establishment and management:** Setting up new geographic areas
- **Teaching/training:** Understanding the complete Natural Areas methodology
- **Reference authority:** Definitive source for all v4.0 specifications

For focused tasks, consider using the modular skills instead:
- **Discovery only:** Use "Natural Areas Discovery Workflow" skill
- **Schema/vocabulary reference:** Use "Natural Areas Schema & Vocabulary" skill  
- **Normalization/output:** Use "Natural Areas Normalization & Output" skill
- **Processing/QA:** Use "Natural Areas Processing & Quality Control" skill

## System Architecture

The Natural Areas Project v4.0 follows a **six-entity ontology** processed through a **four-stage pipeline**:

### Six-Entity Ontology

1. **Site** - Parks, preserves, forests, wildlife areas, recreation areas
2. **Trail** - Named trails within or across sites
3. **Trail Segment** - Distinct sections of trails
4. **Trail Network** - Collections of related trails
5. **Site Network** - Collections of related sites (e.g., State Park System)
6. **Access Point** - Parking areas, trailheads, entrances

All six entity types are identity-bearing with unique IDs and well-defined schemas.

### Four-Stage Processing Pipeline

```
┌─────────────────┐
│  1. DISCOVERY   │  Web search & extraction across 8 tiers
│  (Raw Records)  │  Jurisdictional + Entity-specific discovery
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  2. RESOLUTION  │  Duplicate detection & entity merging
│  (Unique IDs)   │  Multi-source conflict resolution
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 3. NORMALIZATION│  Standardization & vocabulary mapping
│  (Clean Data)   │  Schema validation & quality checks
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  4. ENTITY GRAPH│  Relationship building & TSV output
│  (Final Output) │  Referential integrity & export
└─────────────────┘
```

### Eight-Tier Discovery System

Discovery proceeds systematically through jurisdictional tiers:

1. **Tier 1: State** - State parks, forests, wildlife areas, preserves
2. **Tier 2: Federal** - National parks/forests/refuges, tribal lands
3. **Tier 3: County** - County park districts and recreation departments
4. **Tier 4: District** - Regional park districts, special districts
5. **Tier 5: Township** - Township-owned parks and recreation areas
6. **Tier 6: Municipal** - City and village parks, all municipalities
7. **Tier 7: Conservancy** - Land trusts, conservancies, Audubon, TNC
8. **Tier 8: Private** - Universities, foundations, private organizations

Each tier is completed 100% before advancing to ensure systematic coverage.

## Complete Module Library

This mega-skill includes all 47 active v4.0 modules:

### Schema Modules (9)
Entity definitions and structural rules:
- Site Schema v4.0
- Access Point Schema v4.0
- Trail Schema v4.0
- Trail Segment Schema v4.0
- Trail Network Schema v4.0
- Site Network Schema v4.0
- Child Site Rules v4.0
- Discovery Architecture v4.0
- Entity Graph Schema v4.0

### Vocabulary Modules (6)
Controlled enumerations for all entity types:
- Site Vocabulary v4.0
- Access Point Vocabulary v4.0
- Trail Vocabulary v4.0
- Trail Segment Vocabulary v4.0
- Trail Network Vocabulary v4.0
- Site Network Vocabulary v4.0

### Normalization Modules (8)
Data cleaning and standardization rules:
- Site Normalization v4.0
- Access Point Normalization v4.0
- Trail Normalization v4.0
- Trail Segment Normalization v4.0
- Trail Network Normalization v4.0
- Site Network Normalization v4.0
- Normalization Engine v4.0
- Entity Upsert Engine v4.0

### Discovery System (18)
Systematic discovery workflows:

**Core Protocol (4):**
- Discovery Protocol v4.0
- Discovery Orchestration v4.0
- Discovery Metadata Specification v4.0
- Discovery Output Specification v4.0

**Jurisdictional Sub-Procedures (8):**
- County Discovery Sub-Procedure v4.0
- Municipal Discovery Sub-Procedure v4.0
- Township Discovery Sub-Procedure v4.0
- State Discovery Sub-Procedure v4.0
- Federal/Tribal Discovery Sub-Procedure v4.0
- District Discovery Sub-Procedure v4.0
- Private Discovery Sub-Procedure v4.0
- Conservancy Discovery Sub-Procedure v4.0

**Entity-Specific Sub-Procedures (6):**
- Site Discovery Sub-Procedure v4.0
- Trail Discovery Sub-Procedure v4.0
- Trail Segment Discovery Sub-Procedure v4.0
- Trail Network Discovery Sub-Procedure v4.0
- Site Network Discovery Sub-Procedure v4.0
- Access Point Discovery Sub-Procedure v4.0

### Output Modules (7)
TSV format specifications and validation:
- Site TSV Specifications v4.0
- Access Point TSV Specifications v4.0
- Trail TSV Specifications v4.0
- Trail Segment TSV Specifications v4.0
- Trail Network TSV Specifications v4.0
- Site Network TSV Specifications v4.0
- TSV Integrity Check v4.0

### Workflow & Logic Modules (5)
Processing orchestration and resolution:
- Natural Areas Project Overview v4.0
- Bootstrap Module v4.0
- Processing Module v4.0
- Resolution Module v4.0
- Resolution Engine v4.0

### Audit & Baseline Modules (2)
Quality control and initialization:
- Audit and Logging Module v4.0
- County Baseline Module v4.0

### Manifest (1)
System documentation:
- Module Manifest v4.0

### Best Practices Reference (1)
Methodology improvements:
- Improved Discovery Methodology (lessons learned from real projects)

**TOTAL: 47 authoritative modules + 1 best practices guide**

## Complete Workflow: County Discovery Example

**User Request:** "Complete natural areas discovery for Butler County, Ohio"

**System Execution:**

### Phase 1: Bootstrap & Initialization
```
BOOTSTRAP BUTLER COUNTY, OHIO

1. Load Complete v4.0 System
   ✓ Schema modules (9)
   ✓ Vocabulary modules (6)
   ✓ Normalization modules (8)
   ✓ Discovery modules (18)
   ✓ Output modules (7)
   ✓ Workflow modules (5)
   ✓ Quality modules (2)
   ✓ Manifest + Best Practices (2)

2. Jurisdictional Research
   Municipalities:
   - Cities: Hamilton, Fairfield, Oxford, Monroe, Trenton, Middletown
   - Villages: 7 villages enumerated
   Townships: 13 townships enumerated
   Special Districts: MetroParks of Butler County
   
3. Baseline Establishment
   Expected entities:
   - State: 2-3 sites
   - Federal: 0-1 sites
   - County/District: 20-25 sites (MetroParks)
   - Municipal: 15-25 sites estimated
   - Township: 0-5 sites estimated
   - Private: 3-5 sites estimated
   Total Expected: 45-65 entities
   
4. Session Initialization
   Session ID: BC-OH-20260212-001
   Audit Logging: ENABLED
   Quality Thresholds: v4.0 standards
   Target: 95%+ completeness
```

### Phase 2: Tier-by-Tier Discovery
```
TIER 1: STATE FACILITIES
Method: Search Ohio DNR database + website
Searches:
- "Ohio state parks Butler County"
- "Ohio DNR Butler County"
- "Ohio wildlife areas Butler County"
Found:
- Governor Bebb MetroPark & Pioneer Village (DNR-managed)
- Hueston Woods State Park (partial, mostly in Preble County)
Result: 2 state entities discovered

TIER 2: FEDERAL FACILITIES
Method: Search federal databases
Searches:
- "National Park Service Butler County Ohio"
- "U.S. Forest Service Butler County Ohio"
- "U.S. Fish & Wildlife Butler County Ohio"
Found: None in Butler County
Result: 0 federal entities

TIER 3: COUNTY PARK DISTRICT
Method: Fetch MetroParks of Butler County website
Actions:
- Navigate to metroparks.org
- Fetch parks directory page
- Extract ALL park listings
Found: 22 MetroParks sites
- Chrisholm MetroPark
- Four Mile Creek MetroPark
- Governor Bebb MetroPark
- Miami Whitewater Forest
- [... 18 more sites]
Result: 22 county sites discovered

TIER 4: REGIONAL DISTRICTS
Method: Search for special districts
Result: 0 additional districts

TIER 5: TOWNSHIP PARKS
Method: Search all 13 townships individually
Townships checked:
□ Fairfield Township
□ Hanover Township
□ Liberty Township
□ [... all 13 townships]
Result: 2 township parks found

TIER 6: MUNICIPAL PARKS
Method: Systematic search of ALL municipalities
Cities (6):
✓ Hamilton - Official website fetched
  - Parks department page retrieved
  - Found: 9 city parks
✓ Fairfield - Official website fetched
  - Found: 11 city parks
✓ Oxford - Official website fetched
  - Found: 4 parks (+ university areas)
✓ [... all 6 cities completed]

Villages (7):
✓ Seven Mile - Website fetched
  - Found: 1 village park
✓ [... all 7 villages completed]

Result: 38 municipal parks discovered

TIER 7: CONSERVANCY PRESERVES
Method: Search land trusts and conservancies
- Cincinnati Nature Center (portions in Butler County)
- Local land trusts searched
Result: 2 conservancy sites

TIER 8: PRIVATE PRESERVES
Method: Search universities, foundations
- Miami University natural areas
- Private nature centers
Result: 3 private sites

DISCOVERY TOTALS:
- State: 2 sites
- Federal: 0 sites
- County: 22 sites
- Township: 2 sites
- Municipal: 38 sites
- Conservancy: 2 sites
- Private: 3 sites
TOTAL: 69 sites discovered
```

### Phase 3: Entity-Specific Discovery
```
FOR EACH SITE: Discover associated entities

Sites with Trails:
- Miami Whitewater Forest: 32 miles of trails
  → Discovered: 8 named trails, 15 trail segments
- Chrisholm MetroPark: 12 miles
  → Discovered: 4 trails, 8 segments
[... continued for all trail-bearing sites]

Trail Networks Identified:
- MetroParks Trail System (connects multiple parks)
- Great Miami River Trail (multi-county)

Access Points Cataloged:
- Each site: parking areas, trailheads
- Total: 147 access points discovered

ENTITY TOTALS:
- Sites: 69
- Trails: 94
- Trail Segments: 238
- Trail Networks: 2
- Site Networks: 1 (MetroParks of Butler County)
- Access Points: 147
TOTAL ENTITIES: 551
```

### Phase 4: Resolution & Normalization
```
ENTITY RESOLUTION ENGINE

Duplicate Detection:
- Found 4 potential duplicates
  Example: "Governor Bebb MetroPark" discovered in both
  Tier 1 (State) and Tier 3 (County)
  → Confirmed duplicate, merged with County as operator

Merging Results:
- 4 entities merged
- Result: 547 unique entities

NORMALIZATION ENGINE

Site Name Normalization:
- "MIAMI WHITEWATER FOREST" → "Miami Whitewater Forest"
- "Four Mile Creek Metro Park" → "Four Mile Creek MetroPark"
- [... 69 sites normalized]

Vocabulary Mapping:
- "Community Park" → "Municipal Park"
- "Metro Park" → "County Park"
- "Bike Path" → "Multi-Use Trail"
- [... all vocabularies mapped]

Schema Validation:
✓ All required fields present
✓ Coordinates validated
✓ Addresses standardized
✓ Contact info formatted

Result: 547 normalized, validated entities
```

### Phase 5: Entity Graph & Output
```
ENTITY GRAPH CONSTRUCTION

Nodes Created: 547
Relationships Created:
- Site → Trail: 94 relationships
- Trail → Segment: 238 relationships
- Site → Network: 22 relationships
- Trail → Network: 18 relationships
- Access Point → Site: 147 relationships
Total Edges: 519

Graph Validation:
✓ No circular references
✓ All foreign keys valid
✓ Referential integrity 100%

TSV OUTPUT GENERATION

Files Created:
- Sites.tsv: 69 rows
- Trails.tsv: 94 rows
- Trail_Segments.tsv: 238 rows
- Trail_Networks.tsv: 2 rows
- Site_Networks.tsv: 1 row
- Access_Points.tsv: 147 rows

Total Records: 551 rows across 6 files

Integrity Checks:
✓ All TSV files pass validation
✓ Cross-file references valid
✓ UTF-8 encoding verified
✓ Column structure correct
```

### Phase 6: Quality Assurance & Audit
```
QUALITY METRICS

Discovery Completeness: 98%
- Tier 1 (State): 100%
- Tier 2 (Federal): 100%
- Tier 3 (County): 100%
- Tier 4 (District): 100%
- Tier 5 (Township): 100%
- Tier 6 (Municipal): 96% (all municipalities searched)
- Tier 7 (Conservancy): 95% (known organizations searched)
- Tier 8 (Private): 90% (thorough but may have missed obscure sites)

Data Quality: 99%
- Required fields: 100%
- Format validation: 99%
- Vocabulary compliance: 100%
- Coordinate accuracy: 98%

Resolution Quality: 100%
- Duplicates resolved: 4
- Conflicts: 0
- Manual review: 0

Output Quality: 100%
- TSV integrity: PASS
- Referential integrity: PASS
- File structure: PASS

AUDIT LOG GENERATED

Session Report:
- Session: BC-OH-20260212-001
- Duration: 6.5 hours
- Entities Discovered: 551
- Sources Accessed: 127
- Tools Used: web_search (342 calls), web_fetch (89 calls)
- Quality Level: EXCELLENT

Coverage vs. Baseline:
- Expected: 45-65 entities
- Discovered: 69 sites
- Coverage: 106-153% (exceeded expectations)

Files Generated:
- Sites.tsv (19.4 KB)
- Trails.tsv (12.7 KB)
- Trail_Segments.tsv (28.3 KB)
- Access_Points.tsv (16.1 KB)
- Trail_Networks.tsv (0.4 KB)
- Site_Networks.tsv (0.2 KB)
- audit_log.txt (45.2 KB)
- quality_report.txt (12.8 KB)

PROJECT STATUS: COMPLETE
```

## Key Capabilities Summary

### Discovery
- ✅ Systematic 8-tier jurisdictional coverage
- ✅ 100% entity enumeration (no assumptions)
- ✅ Official page fetching (not snippet reliance)
- ✅ Complete sub-entity extraction
- ✅ Full provenance documentation

### Data Quality
- ✅ Entity resolution with duplicate detection
- ✅ Multi-source conflict resolution
- ✅ Comprehensive normalization rules
- ✅ Controlled vocabulary enforcement
- ✅ Schema validation at every stage

### Relationships
- ✅ Six-entity ontology with well-defined relationships
- ✅ Parent-child site modeling
- ✅ Trail-site associations
- ✅ Network memberships
- ✅ Access point connections

### Output
- ✅ Six standardized TSV files
- ✅ Complete referential integrity
- ✅ Database-ready format
- ✅ Full metadata preservation
- ✅ Character encoding compliance

### Quality Control
- ✅ Baseline validation
- ✅ Completeness metrics
- ✅ Multi-tier quality checks
- ✅ Full audit trails
- ✅ Quality reporting

## Critical Success Factors

### The Three Commandments of Discovery
1. **SYSTEMATIC BEATS SMART**
   - Search every entity, no assumptions about size/likelihood
   - Complete each tier 100% before advancing

2. **FETCH BEATS SEARCH**
   - Always retrieve official pages with web_fetch
   - Never rely on search snippets alone
   - Read complete page content

3. **DOCUMENT BEATS REMEMBER**
   - Record all findings AND non-findings
   - Include sources, dates, methods
   - Full audit trail for every decision

### Data Quality Principles
1. **Provenance Preservation:** Never lose source information
2. **Authority Hierarchy:** Higher authority sources override lower
3. **Vocabulary Control:** Use controlled enums, not freeform
4. **Relationship Integrity:** All foreign keys must be valid
5. **Auditability:** Every transformation documented

### Workflow Principles
1. **Pipeline Order:** Discovery → Resolution → Normalization → Graph → Output
2. **Quality Gates:** Validation at each stage
3. **Fail Fast:** Catch errors early in pipeline
4. **Baseline Validation:** Compare to expected results
5. **Completeness Over Speed:** 95%+ coverage is the goal

## Integration & Modularity

While this mega-skill contains the complete system, it's designed to work modularly:

**Use Complete System When:**
- Full county/regional discovery project
- Need all capabilities end-to-end
- Training/teaching the complete methodology
- Establishing new geographic areas

**Use Modular Skills When:**
- Focused on one phase (discovery only, normalization only)
- Need lightweight schema reference
- Working on specific sub-tasks
- Performance/simplicity preferred

The modular skills can be used together or independently while the mega-skill provides the complete integrated system.

## Reference Documentation

This mega-skill includes complete documentation organized in the `references/` directory structure:

```
references/
├── schema/ (9 modules)
├── vocabularies/ (6 modules)
├── normalization/ (8 modules)
├── discovery/ (18 modules)
├── output/ (7 modules)
├── workflow/ (5 modules)
├── audit/ (1 module)
├── baseline/ (1 module)
├── manifest/ (1 module)
└── best-practices/ (1 guide)
```

All 47 modules plus the improved discovery methodology guide.

## Required Tools

- `web_search` - Finding official sources and databases
- `web_fetch` - Retrieving complete page content (CRITICAL)
- File creation - TSV output and reports
- (Optional) Geocoding for coordinate enrichment

## Version & Maintenance

**Version:** 4.0  
**Last Updated:** February 2026  
**Module Count:** 47 authoritative modules + 1 best practices guide  
**Status:** Production-ready, actively maintained  
**Compatibility:** Designed for Claude with computer use capabilities

### Version History
- v4.0 (2026-02): Six-entity ontology, complete pipeline, 47 modules
- v3.x (deprecated): Five-entity ontology with sub-sites
- v2.x (deprecated): Early normalization-focused version
- v1.x (deprecated): Initial discovery methodology

## Quality Targets

**Discovery:**
- Tier completion: 100% per tier
- Geographic coverage: 95%+ of county entities
- Source documentation: 100%

**Data Quality:**
- Required field completeness: 100%
- Format validation: 98%+
- Vocabulary compliance: 98%+
- Coordinate validity: 95%+

**Resolution:**
- Duplicate detection: 95%+ accuracy
- Conflict resolution: 90%+ automated

**Output:**
- TSV integrity: 100%
- Referential integrity: 99%+
- Character encoding: 100%

## Notes

This mega-skill represents the complete Natural Areas Project v4.0 methodology developed through real-world discovery projects across Ohio counties, incorporating lessons learned from projects like Wood County where systematic methodology improvements led to discovering missed entities (e.g., 3 parks in small villages initially overlooked).

The system is designed for **completeness and quality over speed**, with the philosophy that spending adequate time to achieve 95%+ coverage is more valuable than quick but incomplete results.

The v4.0 architecture with six identity-bearing entity types and a four-stage pipeline provides clarity, flexibility, and auditability for natural areas cataloging at any scale from single counties to statewide systems.

---

**Created by:** Natural Areas Project Team  
**For:** Statewide natural areas cataloging across Ohio and expanding to other states  
**Purpose:** Systematic, comprehensive, quality-controlled discovery and data management  
**Methodology:** Evidence-based, continuously improving through real-world application
