---
name: Natural Areas Schema & Vocabulary
description: Apply Natural Areas Project v4.0 entity schemas and controlled vocabularies when structuring natural areas data, defining fields, or validating entity types
---

# Natural Areas Schema & Vocabulary Skill

## Overview

This skill provides authoritative definitions for the six-entity ontology of the Natural Areas Project v4.0, including complete field schemas and controlled vocabularies for sites, trails, access points, and network entities.

Use this skill when working with natural areas data to ensure proper entity structure, field definitions, relationship modeling, and vocabulary compliance.

## When to Use This Skill

Trigger this skill when users request:
- "What fields does a Site entity have?"
- "Define the Trail schema"
- "What are valid values for [field]?"
- "Structure this natural areas data"
- "Validate this entity definition"
- "What's the difference between a Site and a Site Network?"
- Any request involving natural areas data structure or entity definitions

## Core Capabilities

### 1. Six-Entity Ontology (v4.0)

Provides authoritative definitions for:

**1. Site**
- Primary entity type representing discrete natural areas
- Includes parks, preserves, forests, wildlife areas, recreation areas
- Supports parent-child relationships for complex sites
- Identity-bearing with unique Site_ID

**2. Trail**
- Named trails within or across sites
- Can belong to trail networks
- Identity-bearing with unique Trail_ID

**3. Trail Segment**
- Distinct sections of trails
- Physical pathway components
- Identity-bearing with unique Trail_Segment_ID

**4. Trail Network**
- Collections of related trails
- Can span multiple sites
- Identity-bearing with unique Trail_Network_ID

**5. Site Network**
- Collections of related sites
- Examples: State Park System, County Park District
- Identity-bearing with unique Site_Network_ID

**6. Access Point**
- Parking areas, trailheads, entrances
- Associated with sites and trails
- Identity-bearing with unique Access_Point_ID

### 2. Complete Field Schemas

For each entity type, provides:
- **Required fields** - Must be present
- **Optional fields** - Include when available
- **Field data types** - String, numeric, date, geographic
- **Field constraints** - Length limits, format requirements
- **Relationship fields** - Foreign keys, parent references
- **Metadata fields** - Discovery provenance, timestamps

### 3. Controlled Vocabularies

Authoritative enumerated values for:
- **Site Types:** Nature Preserve, Wildlife Area, State Park, County Park, etc.
- **Trail Types:** Hiking, Biking, Multi-Use, Nature, etc.
- **Trail Surfaces:** Paved, Natural, Gravel, Boardwalk, etc.
- **Trail Difficulties:** Easy, Moderate, Difficult, Expert
- **Access Point Types:** Parking Lot, Trailhead, Entrance, Gate, etc.
- **Ownership Types:** State, Federal, County, Municipal, Private, etc.
- **Jurisdictional Authorities:** State DNR, County Park District, Municipality, etc.

### 4. Entity Relationship Rules

Defines valid relationships:
- **Site → Child Sites** (Parent-Child hierarchy)
- **Site → Trails** (Contains relationship)
- **Trail → Trail Segments** (Composed-of relationship)
- **Trail → Trail Network** (Member-of relationship)
- **Site → Site Network** (Member-of relationship)
- **Access Point → Site** (Serves relationship)
- **Access Point → Trail** (Provides-access-to relationship)

### 5. Child Site Rules

Special handling for complex sites:
- When to model as Child Sites vs. separate Sites
- Parent Site reference requirements
- Naming conventions for child sites
- Boundary relationship rules
- Independent vs. dependent child sites

## Field Schema Examples

### Site Schema (Abbreviated)
```
REQUIRED FIELDS:
- Site_ID (unique identifier)
- Site_Name (official name)
- Site_Type (from controlled vocabulary)
- County (administrative county)
- State (two-letter code)
- Ownership (from controlled vocabulary)
- Jurisdiction (managing authority)

OPTIONAL FIELDS:
- Parent_Site_ID (for child sites)
- Site_Network_ID (network membership)
- Acreage (numeric)
- Address (full street address)
- Latitude/Longitude (decimal degrees)
- Hours_of_Operation
- Amenities (comma-separated)
- Contact_Phone
- Contact_Email
- Website_URL
- Description
- Established_Date

METADATA FIELDS:
- Discovery_Tier
- Discovery_Source
- Discovery_Date
- Last_Verified
```

### Trail Schema (Abbreviated)
```
REQUIRED FIELDS:
- Trail_ID (unique identifier)
- Trail_Name (official name)
- Trail_Type (from controlled vocabulary)
- Primary_Site_ID (main site)

OPTIONAL FIELDS:
- Trail_Network_ID (network membership)
- Trail_Length_Miles (numeric)
- Trail_Surface (from controlled vocabulary)
- Trail_Difficulty (from controlled vocabulary)
- Trail_Blaze_Color
- Loop_vs_OutAndBack
- Elevation_Gain_Feet
- Description
- Trail_Map_URL

RELATIONSHIP FIELDS:
- Sites_Traversed (comma-separated Site_IDs)
- Access_Points (comma-separated Access_Point_IDs)
```

## Vocabulary Validation

The skill provides validation against controlled vocabularies:

**Site_Type valid values:**
- State Park
- State Forest
- State Nature Preserve
- Wildlife Area
- National Park
- National Forest
- National Wildlife Refuge
- County Park
- Municipal Park
- Township Park
- Nature Preserve
- Nature Center
- Conservation Area
- Recreation Area
- Greenway
- Trail System
- (See complete list in reference documentation)

**Trail_Type valid values:**
- Hiking
- Mountain Biking
- Shared Use / Multi-Use
- Nature Trail
- Interpretive Trail
- Bridle Trail / Equestrian
- Cross-Country Skiing
- Snowshoeing
- All-Purpose Trail
- (See complete list in reference documentation)

## Entity Graph Schema

Defines how entities relate in a graph structure:
- **Nodes:** The six entity types
- **Edges:** Typed relationships between entities
- **Properties:** Entity attributes
- **Constraints:** Relationship cardinality rules
- **Graph Operations:** Traversal patterns, queries

## Reference Documentation

The skill includes 15 authoritative modules:

### Schema Modules (9)
- Site Schema v4.0
- Access Point Schema v4.0
- Trail Schema v4.0
- Trail Segment Schema v4.0
- Trail Network Schema v4.0
- Site Network Schema v4.0
- Child Site Rules v4.0
- Discovery Architecture v4.0
- Entity Graph Schema v4.0

### Vocabulary Modules (6)
- Site Vocabulary v4.0
- Access Point Vocabulary v4.0
- Trail Vocabulary v4.0
- Trail Segment Vocabulary v4.0
- Trail Network Vocabulary v4.0
- Site Network Vocabulary v4.0

See the `references/` directories for complete module documentation.

## Example Usage

**User:** "What fields do I need for a hiking trail?"

**Claude responds using this skill:**
```
A Trail entity in the Natural Areas Project requires:

REQUIRED FIELDS:
- Trail_ID: Unique identifier
- Trail_Name: Official trail name
- Trail_Type: "Hiking" (from controlled vocabulary)
- Primary_Site_ID: ID of the site containing the trail

RECOMMENDED FIELDS:
- Trail_Length_Miles: Length in miles
- Trail_Difficulty: Easy/Moderate/Difficult
- Trail_Surface: Paved/Natural/Gravel/etc.
- Loop_vs_OutAndBack: Trail configuration
- Description: Trail description

OPTIONAL FIELDS:
- Trail_Network_ID: If part of a larger trail system
- Elevation_Gain_Feet: Total elevation gain
- Trail_Blaze_Color: Trail marking color
- Trail_Map_URL: Link to trail map
- Access_Points: Trailhead IDs (comma-separated)

All fields validated against v4.0 schema specifications.
```

**User:** "Is 'Community Park' a valid Site_Type?"

**Claude validates against controlled vocabulary:**
```
No, "Community Park" is not in the controlled vocabulary.

Valid municipal park types include:
- Municipal Park
- Township Park
- Village Park

For your use case, "Municipal Park" is likely the correct value.

(Vocabulary reference: Site Vocabulary v4.0, Municipal category)
```

## Integration with Other Skills

This skill works with:
- **Discovery Workflow Skill:** Provides entity definitions for discovered items
- **Normalization & Output Skill:** Provides schema for validation and TSV output
- **Processing Skill:** Provides entity models for resolution and graph building

## Data Quality Rules

The schemas enforce:
- **Required field completeness:** All required fields must have values
- **Vocabulary compliance:** Enumerated fields must use valid values
- **Relationship integrity:** Foreign keys must reference valid entities
- **Format compliance:** Dates, coordinates, URLs must match formats
- **Uniqueness constraints:** IDs must be globally unique

## Key Principles

1. **Single Source of Truth:** All entity definitions come from v4.0 schemas
2. **Vocabulary Control:** Use enumerated values, never freeform where controlled
3. **Relationship Clarity:** Every relationship has defined semantics
4. **Child Site Clarity:** Follow rules for when to use parent-child vs. separate entities
5. **Metadata Preservation:** Always include discovery provenance

## Notes

### Important Architectural Decisions

**v4.0 Ontology Changes:**
- Sub-Sites are DEPRECATED in v4.0
- Child Sites are now represented as Sites with Parent_Site_ID
- Access Point Association is deprecated (use direct references)

**Entity Identity:**
All six entity types are identity-bearing:
- Each has unique ID
- Each can exist independently
- Each has well-defined lifecycle
- Each has authoritative schema

**Relationship Modeling:**
- Sites can contain trails
- Trails can span multiple sites
- Both sites and trails can be members of networks
- Access points can serve multiple sites/trails

---

**Version:** 4.0  
**Last Updated:** February 2026  
**Module Count:** 15 schema and vocabulary modules
