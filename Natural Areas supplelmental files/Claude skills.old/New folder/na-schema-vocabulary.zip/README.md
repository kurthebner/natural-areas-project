# Natural Areas Schema & Vocabulary Skill

## Overview
Authoritative entity definitions and controlled vocabularies for the six-entity Natural Areas ontology.

## Module Count
15 modules (9 schemas + 6 vocabularies)

## Key Features
- Six-entity ontology (v4.0)
- Complete field schemas for all entities
- Controlled vocabulary enumerations
- Entity relationship rules
- Child site handling rules

## When to Use
- Structuring natural areas data
- Validating entity definitions
- Checking field requirements
- Applying controlled vocabularies

## Entity Types
- Sites
- Trails
- Trail Segments
- Trail Networks
- Site Networks
- Access Points

## Version
v4.0 - February 2026

## Part of
Natural Areas Project Complete System
