# Natural Areas Processing & Quality Control

Workflow orchestration, entity resolution, audit logging, and baseline management.

## Trigger Words
bootstrap, setup county, orchestrate, quality audit, baseline, pipeline, resolve conflicts

## What It Does
- Bootstrap new county projects
- Orchestrate complete workflow pipeline
- Resolve duplicate entities
- Manage county baselines
- Generate audit logs
- Run quality validation

## When to Use
- Setting up new county projects
- Orchestrating complete workflows
- Resolving entity conflicts
- Running quality audits
- Managing baselines

## Module Count
9 modules (5 workflow + 2 quality + 2 reference)

## Usage Examples
- "Bootstrap Franklin County, Ohio"
- "Set up new discovery project for Butler County"
- "Run quality validation on this data"

## Version
v4.0 - February 2026
