---
name: na-processing-quality
description: Orchestrate workflows, manage baselines, run quality audits, and resolve entity conflicts. USE THIS SKILL when user wants to bootstrap a project, setup a new county, orchestrate the pipeline, run quality checks, or manage baselines.
---

# Natural Areas Processing & Quality Control

Workflow orchestration, entity resolution, audit logging, and baseline management for Natural Areas projects.

## Bootstrap New County

When starting a new county project:

1. **Load bootstrap module**: `view references/workflow/na_bootstrap.md`
2. **Research jurisdiction**: List all municipalities, townships, districts
3. **Establish baseline**: Document expected entities (see baseline reference)
4. **Initialize session**: Set session ID, start audit log
5. **Ready for discovery**: Begin tier-based discovery

**Bootstrap Checklist**:
```
County: [Name], [State]
Municipalities: [count cities] cities + [count villages] villages
Townships: [count] townships
Expected entities: [range estimate]
Session ID: [COUNTY]-[STATE]-[YYYYMMDD]-[seq]
```

## Processing Pipeline

Complete workflow orchestration:

```
Discovery → Resolution → Normalization → Entity Graph → Output → Audit
```

See `references/workflow/na_processing.md` for full pipeline details.

## Entity Resolution

Duplicate detection and merging:

**Detection Strategies**:
- Exact match: same name + county
- Coordinate match: within 100m
- Fuzzy match: similar names, near coordinates

**Resolution Rules**:
See `references/workflow/na_resolution_engine.md`

**Authority Hierarchy**:
State > County > Municipal > Private

**Conflict Handling**:
- Higher authority wins
- Most recent when equal
- Flag for manual review if unresolvable

## County Baseline

Establish expected entities before discovery:

**Baseline Components**:
- Complete municipality list (cities + villages)
- Complete township list
- Regional districts
- Known major sites
- Expected entity counts by tier

See `references/baseline/na_county_baseline.md`

**Use Baseline**:
- Pre-discovery: Set expectations
- During: Validate completeness
- Post: Calculate coverage percentage

## Quality Validation

Multi-tier quality checks:

**Discovery Quality**:
- Tier completion: 100% entities searched
- Source documentation: 100%
- Coverage: 95%+ target

**Data Quality**:
- Required fields: 100%
- Format validation: 98%+
- Vocabulary compliance: 98%+

**Output Quality**:
- TSV integrity: 100%
- Referential integrity: 99%+

## Audit Logging

Track all operations:

**Audit Trail Includes**:
- Session metadata (ID, timestamps, geography)
- Discovery actions (tiers, sources, entities found)
- Resolution decisions (merges, conflicts)
- Normalization transformations
- Quality metrics
- Output generation

See `references/audit/na_audit_and_logging.md`

## Reference Documentation

**Workflow Orchestration**:
- `references/workflow/na_bootstrap.md` - Session initialization
- `references/workflow/na_processing.md` - Pipeline orchestration
- `references/workflow/na_resolution.md` - Conflict resolution
- `references/workflow/na_resolution_engine.md` - Resolution algorithms
- `references/na_module_manifest.md` - System architecture

**Quality Control**:
- `references/audit/na_audit_and_logging.md` - Audit framework
- `references/baseline/na_county_baseline.md` - Baseline management

## Example Session

**User**: "Set up discovery for Franklin County, Ohio"

**Execute**:
1. Research jurisdiction (15 cities + 14 townships)
2. Create baseline (expected 50-60 entities)
3. Initialize session (FC-OH-20260213-001)
4. Ready for tier-based discovery

## Quality Metrics Dashboard

Example output:
```
Discovery Completeness: 96%
  State: 100%
  County: 100%
  Municipal: 94%
  Private: 85%

Data Quality: 97%
  Required Fields: 100%
  Format Validation: 96%
  Vocabulary: 98%

Resolution: 99%
  Duplicates Merged: 12
  Conflicts: 2 flagged

Output: 100%
  TSV Integrity: PASS
  Referential: PASS
```

## Key Principles

**Completeness over Speed**: Take time to achieve 95%+ coverage
**Document Everything**: Full audit trail for all decisions
**Baseline Validation**: Compare discovered vs expected
**Quality Gates**: Validation at each pipeline stage
