---
name: na-schema-vocabulary
description: Define entity schemas and controlled vocabularies for natural areas data. USE THIS SKILL when user asks about entity structure, field requirements, valid values, data models, or mentions Site, Trail, Access Point, or network entities.
---

# Natural Areas Schema & Vocabulary

Authoritative entity definitions and controlled vocabularies for the six-entity Natural Areas ontology v4.0.

## Six Entity Types

All identity-bearing with unique IDs:

1. **Site** - Parks, preserves, forests, wildlife areas, recreation areas
2. **Trail** - Named trails within or across sites
3. **Trail Segment** - Distinct sections of trails
4. **Trail Network** - Collections of related trails
5. **Site Network** - Collections of related sites (e.g., State Park System)
6. **Access Point** - Parking areas, trailheads, entrances

## Quick Field Reference

**Site** - Required: Site_ID, Site_Name, Site_Type, County, State, Ownership, Jurisdiction
**Trail** - Required: Trail_ID, Trail_Name, Trail_Type, Primary_Site_ID
**Access Point** - Required: Access_Point_ID, Name, Type, Primary_Site_ID

See schema references for complete field lists.

## Common Field Questions

**What fields does a Site need?**
See `references/schema/na_site_schema.md`

**Valid Site_Type values?**
See `references/vocabularies/na_site_vocabulary.md`

**How do parent-child sites work?**
See `references/schema/na_child_site_rules.md`

**Trail difficulty levels?**
See `references/vocabularies/na_trail_vocabulary.md`

## Entity Relationships

- **Site → Child Sites**: Use Parent_Site_ID field
- **Site → Trails**: Contains relationship via Primary_Site_ID
- **Trail → Segments**: Composed-of via Trail_ID
- **Site/Trail → Networks**: Member-of via Network_ID
- **Access Point → Site/Trail**: Serves via reference IDs

## Common Vocabulary Values

**Site Types**: State Park, State Forest, County Park, Municipal Park, Nature Preserve, Wildlife Area, Recreation Area

**Trail Types**: Hiking, Mountain Biking, Multi-Use, Nature Trail, Equestrian

**Trail Surfaces**: Paved, Natural, Gravel, Boardwalk

**Trail Difficulties**: Easy, Moderate, Difficult, Expert

**Ownership**: State, Federal, County, Municipal, Township, Private, Non-Profit

See vocabulary references for complete lists.

## Reference Documentation

**Schemas** (complete field definitions):
- `references/schema/na_site_schema.md`
- `references/schema/na_trail_schema.md`
- `references/schema/na_trail_segment_schema.md`
- `references/schema/na_access_point_schema.md`
- `references/schema/na_trail_network_schema.md`
- `references/schema/na_site_network_schema.md`
- `references/schema/na_child_site_rules.md`
- `references/schema/na_entity_graph_schema.md`
- `references/schema/na_discovery_architecture.md`

**Vocabularies** (controlled enumerations):
- `references/vocabularies/na_site_vocabulary.md`
- `references/vocabularies/na_trail_vocabulary.md`
- `references/vocabularies/na_trail_segment_vocabulary.md`
- `references/vocabularies/na_access_point_vocabulary.md`
- `references/vocabularies/na_trail_network_vocabulary.md`
- `references/vocabularies/na_site_network_vocabulary.md`

## Key Architectural Notes

**v4.0 Changes**:
- Sub-Sites are deprecated - use Parent_Site_ID instead
- All six entity types are identity-bearing
- Access Point Association deprecated - use direct references

**Child Site Rules**:
When to use Parent_Site_ID vs separate Sites - see child site rules reference for decision criteria.

**Entity Graph**:
How entities relate in graph structure - see entity graph schema reference.
