# Natural Areas Schema & Vocabulary

Authoritative entity definitions and controlled vocabularies for the six-entity Natural Areas ontology.

## Trigger Words
entity structure, field requirements, valid values, data models, Site, Trail, Access Point, schema, vocabulary

## What It Does
- Define schemas for 6 entity types
- Provide controlled vocabularies
- Document entity relationships
- Validate data against standards

## When to Use
- Structuring natural areas data
- Validating entity definitions
- Checking field requirements
- Applying controlled vocabularies

## Entity Types
Sites, Trails, Trail Segments, Trail Networks, Site Networks, Access Points

## Module Count
15 modules (9 schemas + 6 vocabularies)

## Usage Examples
- "What fields does a Site entity require?"
- "Show me valid Trail_Type values"
- "How do parent-child sites work?"

## Version
v4.0 - February 2026
