# Natural Areas Complete System

Complete end-to-end Natural Areas Project v4.0 system with all 47 modules.

## Trigger Words
county discovery, complete cataloging, full pipeline, bootstrap and discover, comprehensive natural areas project

## What It Does
Complete integrated system:
- 8-tier systematic discovery
- 6-entity ontology with schemas
- Controlled vocabularies
- Entity resolution & duplicate detection
- Comprehensive normalization
- TSV output generation
- Quality validation & audit logging
- Baseline management

## When to Use
- Full county/regional discovery projects
- Complete end-to-end workflows
- Comprehensive cataloging needs
- System reference and training

## System Architecture
- **Six-Entity Ontology:** Sites, Trails, Segments, Networks, Access Points
- **Eight-Tier Discovery:** State → Federal → County → District → Township → Municipal → Conservancy → Private
- **Four-Stage Pipeline:** Discovery → Resolution → Normalization → Output

## Module Count
All 47 v4.0 modules + best practices guide

## Usage Examples
- "Discover all parks in Butler County, Ohio"
- "Complete natural areas project for Franklin County"
- "Bootstrap and discover Wood County"

## Quality Targets
- Discovery: 95%+ coverage
- Data quality: 98%+
- Referential integrity: 99%+
- TSV integrity: 100%

## Version
v4.0 - February 2026

## Note
For focused tasks, consider using the modular skills instead. This mega-skill includes everything for comprehensive projects.
