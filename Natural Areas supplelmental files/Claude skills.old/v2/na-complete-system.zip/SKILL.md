---
name: na-complete-system
description: Complete Natural Areas Project v4.0 system for discovering, cataloging, normalizing, and managing natural areas data. USE THIS SKILL for full county projects, comprehensive discovery workflows, or when user needs complete end-to-end natural areas system from discovery through output. Triggers include county discovery, complete cataloging, full pipeline, bootstrap and discover.
---

# Natural Areas Complete System v4.0

Complete end-to-end system for natural areas discovery, cataloging, and data management.

## Quick Start for County Discovery

**User says**: "Discover all parks in [County], [State]"

**Execute**:
1. **Bootstrap**: Setup county project (see Processing section below)
2. **Discover**: Execute 8-tier discovery (see Discovery section below)
3. **Normalize**: Clean and validate data (see Normalization section)
4. **Output**: Generate TSV files (see Output section)
5. **Audit**: Create quality report (see Quality section)

## System Architecture

**Six-Entity Ontology**: Sites, Trails, Segments, Networks, Access Points
**Eight-Tier Discovery**: State → Federal → County → District → Township → Municipal → Conservancy → Private
**Four-Stage Pipeline**: Discovery → Resolution → Normalization → Output

## Discovery Workflow

### Read First
`view references/best-practices/improved_discovery_methodology.md`

### 8-Tier Systematic Discovery

Execute tiers in order, 100% complete each before advancing:

1. **State**: `view references/discovery/na_state_discovery_subproc.md`
2. **Federal**: `view references/discovery/na_fed_tribal_discovery_subproc.md`
3. **County**: `view references/discovery/na_county_discovery_subproc.md`
4. **District**: `view references/discovery/na_district_discovery_subproc.md`
5. **Township**: `view references/discovery/na_township_discovery_subproc.md`
6. **Municipal**: `view references/discovery/na_municipal_discovery_subproc.md`
7. **Conservancy**: `view references/discovery/na_conservancy_discovery_subproc.md`
8. **Private**: `view references/discovery/na_private_discovery_subproc.md`

### Critical Rules

**SYSTEMATIC BEATS SMART**: Search every entity individually
**FETCH BEATS SEARCH**: Use `web_fetch` on official pages
**DOCUMENT BEATS REMEMBER**: Record all sources and dates

### Discovery Protocol
See `references/discovery/na_discovery_protocol.md`

## Entity Schemas & Vocabularies

### Quick Reference

**Site** - Required: Site_ID, Site_Name, Site_Type, County, State, Ownership
**Trail** - Required: Trail_ID, Trail_Name, Trail_Type, Primary_Site_ID
**Access Point** - Required: Access_Point_ID, Name, Type, Primary_Site_ID

### Complete Schemas
- `references/schema/na_site_schema.md`
- `references/schema/na_trail_schema.md`
- `references/schema/na_trail_segment_schema.md`
- `references/schema/na_access_point_schema.md`
- `references/schema/na_trail_network_schema.md`
- `references/schema/na_site_network_schema.md`

### Controlled Vocabularies
- `references/vocabularies/na_site_vocabulary.md`
- `references/vocabularies/na_trail_vocabulary.md`
- (see vocabularies directory for all)

## Normalization & Output

### Normalization Workflow

1. **Load engine**: `view references/normalization/na_normalization_engine.md`
2. **Apply entity rules**: See entity-specific normalization files
3. **Resolve duplicates**: `view references/normalization/na_entity_upsert_engine.md`
4. **Validate quality**: Check fields, formats, vocabularies

### TSV Output Generation

Generate six files:
- Sites.tsv
- Trails.tsv
- Trail_Segments.tsv
- Access_Points.tsv
- Trail_Networks.tsv
- Site_Networks.tsv

See `references/output/` directory for TSV specifications
Run `references/output/na_tsv_integrity_check.md` for validation

## Processing & Quality Control

### Bootstrap New County

1. `view references/workflow/na_bootstrap.md`
2. Research municipalities and townships
3. `view references/baseline/na_county_baseline.md` - Establish baseline
4. Initialize session with ID format: COUNTY-STATE-YYYYMMDD-seq

### Pipeline Orchestration

`view references/workflow/na_processing.md`

### Entity Resolution

`view references/workflow/na_resolution_engine.md`

### Audit Logging

`view references/audit/na_audit_and_logging.md`

## Module Organization

All 47 v4.0 modules organized in `references/`:

```
references/
├── best-practices/
│   └── improved_discovery_methodology.md
├── discovery/ (18 modules)
│   ├── na_discovery_protocol.md
│   ├── [jurisdictional discovery procedures]
│   └── [entity discovery procedures]
├── schema/ (9 modules)
├── vocabularies/ (6 modules)
├── normalization/ (8 modules)
├── output/ (7 modules)
├── workflow/ (5 modules)
├── audit/ (1 module)
└── baseline/ (1 module)
```

## Common Workflows

### Full County Discovery
```
1. Bootstrap county
2. Tier 1-8 discovery
3. Entity-specific discovery (trails, access points)
4. Normalize data
5. Generate TSV output
6. Quality validation
7. Audit report
```

### Update Methodology
```
User: "We discovered a new pattern - update methodology"
1. Edit references/best-practices/improved_discovery_methodology.md
2. Document the new pattern
3. Reference in relevant discovery modules
```

### Schema Validation
```
User: "Validate this site data"
1. Load references/schema/na_site_schema.md
2. Check required fields
3. Load references/vocabularies/na_site_vocabulary.md
4. Validate enumerated values
```

## Quality Targets

- Discovery coverage: 95%+
- Data quality: 98%+
- Referential integrity: 99%+
- TSV integrity: 100%

## Key References by Use Case

**Starting discovery?** → `references/best-practices/improved_discovery_methodology.md`
**Need schema?** → `references/schema/`
**Normalizing data?** → `references/normalization/na_normalization_engine.md`
**Generating output?** → `references/output/`
**Quality checking?** → `references/audit/na_audit_and_logging.md`

## System Principles

**Completeness over Speed**: 95%+ coverage worth the time
**Systematic Execution**: Follow methodology, don't skip steps
**Full Documentation**: Audit trail for all decisions
**Continuous Improvement**: Capture new patterns, update methodology
**Evidence-Based**: Document sources, dates, methods for everything
