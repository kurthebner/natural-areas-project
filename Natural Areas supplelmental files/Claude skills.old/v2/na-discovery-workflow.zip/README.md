# Natural Areas Discovery Workflow

Systematic tier-based discovery of natural areas, parks, trails, and preserves across jurisdictions.

## Trigger Words
discover, catalog, find parks, natural areas, county discovery, outdoor recreation

## What It Does
- 8-tier jurisdictional discovery (State → Private)
- Systematic methodology with 95%+ completeness target
- Web search and fetch-based extraction
- Full provenance documentation

## When to Use
- Discovering parks and trails in a county or region
- Systematic natural areas cataloging
- Quality-controlled discovery projects

## Module Count
18 discovery modules + best practices guide

## Usage Examples
- "Discover all parks in Butler County, Ohio"
- "Find trails and natural areas in Franklin County"
- "Start systematic discovery for Wood County"

## Version
v4.0 - February 2026
