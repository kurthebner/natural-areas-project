---
name: na-discovery-workflow
description: Execute systematic discovery of natural areas, parks, trails, and preserves across jurisdictions using tier-based methodology. USE THIS SKILL when user says discover, catalog, find parks, natural areas, county discovery, or mentions discovering outdoor recreation areas in any geographic location.
---

# Natural Areas Discovery Workflow

Execute tier-based discovery of parks, trails, and natural areas across any U.S. county.

## Quick Start

When user requests county discovery:

1. **Read methodology first**: `view references/improved_discovery_methodology.md`
2. **Load discovery protocol**: `view references/workflow/na_discovery_protocol.md`
3. **Execute tier-by-tier**: Follow 8-tier systematic approach
4. **Document as you go**: Track sources, methods, dates

## Core Principle

**SYSTEMATIC BEATS SMART**: Search every entity individually, no assumptions based on size.

## 8-Tier Discovery Sequence

Execute tiers in order, complete each 100% before advancing:

1. **State**: State parks, forests, wildlife areas
2. **Federal**: National parks/forests/refuges, tribal lands  
3. **County**: County park districts
4. **District**: Regional park districts
5. **Township**: Township parks
6. **Municipal**: ALL cities and villages (critical - search each individually)
7. **Conservancy**: Land trusts, Nature Conservancy
8. **Private**: Universities, foundations, private organizations

## Critical Rules

**Never skip entities**: Small villages have parks - check every one
**Always fetch pages**: Use `web_fetch` on official sites, never rely on search snippets
**Extract everything**: Read complete pages, verify counts match claims
**Document negatives**: Record "no parks found" with evidence, not assumptions

## Discovery Workflow

For each tier:

```
1. Enumerate all entities (get complete list FIRST)
2. Search each entity individually
3. Fetch official website/parks page  
4. Extract ALL sub-entities from full page content
5. Verify extracted count matches page claims
6. Document source and date
7. Mark tier complete only after 100% coverage
```

## For Each Discovered Site

After tier discovery, discover entity relationships:

- Associated trails (see `references/workflow/na_trail_discovery_subproc.md`)
- Trail segments
- Access points (parking, trailheads)
- Network memberships

## Reference Documentation

**Core Protocol** (read when needed):
- `references/workflow/na_discovery_protocol.md` - Discovery rules and entity definitions
- `references/workflow/na_discovery_orchestration.md` - Execution order and state management
- `references/workflow/na_discovery_metadata_spec.md` - Metadata structure
- `references/workflow/na_discovery_output_spec.md` - Output format requirements

**Methodology** (read first):
- `references/improved_discovery_methodology.md` - Lessons learned, best practices

**Jurisdictional Discovery** (read for specific tier):
- `references/workflow/na_state_discovery_subproc.md`
- `references/workflow/na_county_discovery_subproc.md`
- `references/workflow/na_municipal_discovery_subproc.md`
- `references/workflow/na_township_discovery_subproc.md`
- `references/workflow/na_fed_tribal_discovery_subproc.md`
- `references/workflow/na_district_discovery_subproc.md`
- `references/workflow/na_private_discovery_subproc.md`
- `references/workflow/na_conservancy_discovery_subproc.md`

**Entity Discovery** (read when discovering entity type):
- `references/workflow/na_site_discovery_subproc.md`
- `references/workflow/na_trail_discovery_subproc.md`
- `references/workflow/na_trail_segment_discovery_subproc.md`
- `references/workflow/na_access_point_discovery_subproc.md`

## Common Failures to Avoid

From real projects - don't make these mistakes:

❌ Skipping small villages ("they probably don't have parks")
❌ Stopping at "good enough" (60 entities when 70+ exist)
❌ Using search snippets instead of fetching full pages
❌ Missing multiple entities listed on same page
❌ Assuming townships don't have parks

## Output Format

Generate discovery records with:
- Entity names and types
- Geographic data (coordinates, addresses)
- Jurisdictional information
- Source URLs and dates
- Discovery tier
- All relationship data

See `references/workflow/na_discovery_output_spec.md` for complete format.

## Quality Target

95%+ completeness - if someone visits official government websites, they shouldn't easily find entities you missed.
