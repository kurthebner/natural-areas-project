# Natural Areas Normalization & Output

Transform raw discovery data into clean, normalized entities and standardized TSV output files.

## Trigger Words
normalize, clean, standardize, export, TSV output, data validation, database import

## What It Does
- Normalize raw discovery data
- Apply controlled vocabulary mappings
- Detect and merge duplicate entities
- Validate data quality
- Generate 6 TSV output files
- Run integrity checks

## When to Use
- Cleaning discovered data
- Standardizing entity records
- Generating database exports
- Validating data quality

## Module Count
15 modules (8 normalization + 7 output specifications)

## Usage Examples
- "Normalize this discovery data"
- "Generate TSV output from these entities"
- "Clean and validate this parks data"

## Version
v4.0 - February 2026
