---
name: na-normalization-output
description: Normalize raw discovery data and generate TSV output files. USE THIS SKILL when user asks to normalize, clean, standardize, or export natural areas data, or mentions TSV output, data validation, or preparing data for database import.
---

# Natural Areas Normalization & Output

Transform raw discovery data into clean, normalized entities and standardized TSV output files.

## Quick Start

When user provides raw discovery data:

1. **Load normalization engine**: `view references/normalization/na_normalization_engine.md`
2. **Apply entity-specific rules**: See entity normalization references
3. **Validate quality**: Check required fields, formats, vocabularies
4. **Generate TSV**: See output specifications
5. **Run integrity check**: Validate cross-file references

## Normalization Workflow

```
Raw Discovery → Entity Resolution → Normalization → Validation → TSV Output
```

## Common Normalizations

**Site Names**:
- "The Metroparks of Butler County - Park Name" → "Park Name"
- "WILDWOOD PRESERVE" → "Wildwood Preserve"
- "Ft. Meigs" → "Fort Meigs"

**Site Types** (vocabulary mapping):
- "County Metro Park" → "County Park"
- "State Nature Pres." → "State Nature Preserve"
- "Local Park" → "Municipal Park"

**Coordinates**:
- DMS to decimal degrees
- Validate ranges (latitude, longitude)
- Standard precision (6 decimals)

**Trail Difficulty**:
- "Easy to Moderate" → "Moderate"
- "Family Friendly" → "Easy"
- "Advanced" → "Difficult"

## Entity Resolution

Detect and merge duplicates:

**Exact Match Criteria**:
- Same name + same county
- Same coordinates (within 100m)
- Same address

**Authority Hierarchy** (highest wins):
1. State official source
2. County source
3. Municipal source
4. Private source

**Conflict Resolution**:
- Higher authority wins
- Most recent when authority equal
- Most complete record wins
- Flag unresolvable for review

## TSV Output Files

Generate six files:

1. `Sites.tsv`
2. `Trails.tsv`
3. `Trail_Segments.tsv`
4. `Trail_Networks.tsv`
5. `Site_Networks.tsv`
6. `Access_Points.tsv`

**Format Requirements**:
- Tab-delimited
- UTF-8 encoding
- Header row with field names
- Empty string for NULL values
- No embedded tabs in content

See `references/output/na_tsv_integrity_check.md` for validation rules.

## Quality Validation

**Required Field Check**: All required fields present, no NULLs
**Format Validation**: Dates ISO 8601, coordinates decimal degrees
**Vocabulary Compliance**: Enumerated fields use valid values
**Referential Integrity**: All foreign keys reference valid entities
**Cross-Field Validation**: County/State valid, coordinates in bounds
**Duplicate Detection**: Check name, location, description similarity

## Reference Documentation

**Normalization Rules** (entity-specific):
- `references/normalization/na_site_normalization.md`
- `references/normalization/na_trail_normalization.md`
- `references/normalization/na_trail_segment_normalization.md`
- `references/normalization/na_access_point_normalization.md`
- `references/normalization/na_trail_network_normalization.md`
- `references/normalization/na_site_network_normalization.md`

**Processing Engines**:
- `references/normalization/na_normalization_engine.md` - Core rules
- `references/normalization/na_entity_upsert_engine.md` - Duplicate handling

**Output Specifications** (TSV format):
- `references/output/na_site_tsv_specs.md`
- `references/output/na_trail_tsv_specs.md`
- `references/output/na_trail_segment_tsv_specs.md`
- `references/output/na_access_point_tsv_specs.md`
- `references/output/na_trail_network_tsv_specs.md`
- `references/output/na_site_network_tsv_specs.md`
- `references/output/na_tsv_integrity_check.md` - Final validation

## Quality Targets

- Required field completeness: 100%
- Format validation: 98%+
- Vocabulary compliance: 98%+
- Referential integrity: 99%+
- TSV integrity: 100%

## Common Issues

**Missing Negatives**: Longitude should be negative for U.S. locations
**Special Characters**: Properly escape tabs/newlines in TSV content
**Vocabulary Variations**: Map all variations to standard terms
**Orphaned References**: Ensure all FK references exist
**Duplicate IDs**: Check uniqueness across all entities
