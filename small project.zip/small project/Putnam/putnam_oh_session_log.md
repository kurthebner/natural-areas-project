# Putnam County OH — Session Log
**RUN_ID:** `putnam_oh_2026_05_07`
**PREFIX:** `PUT`
**County:** Putnam, Ohio
**Run date:** 2026-05-07
**Status:** IN PROGRESS — T1 complete; T2 ready for Copilot (IMP-092 hybrid test)

---

## Discovery — Tier Yield

| Tier | Source Type | Query / Source | Entities Found |
|------|-------------|----------------|----------------|
| T1 | Federal & Tribal | NPS (nps.gov/noco), USFWS (fws.gov), Army Corps, BLM, BTA/NCT (buckeyetrail.org/sections/delphos.php), NPS NHA list | 1 Trail (NCT/NOCO); Trail Network known_existing (PAU-TN-001); Site null; Trail Segment null; Site Network null; Access Point null; Tribal null |
| T2 | State | ODNR (wildlife areas, nature preserves, canal) | — |
| T3 | District | Park districts, conservancy districts | — |
| T4 | County | Putnam County parks / Putnam Parks & Pathways | — |
| T5 | Township | 15 active townships (from Townships_Officials2022-2023.xlsx) | — |
| T6 | Municipal | Ottawa, Columbus Grove, and other municipalities | — |
| T7 | Conservancy & Land Trust | Black Swamp Conservancy, BTA, others | — |
| T8 | Private | Private conservation areas | — |

**Total raw records:** (in progress)
**Post-resolution:** TBD

---

## Normalization Decisions

*(Populated during pipeline stage — see handoff for discovery-time flags)*

---

## GPS Acquisition

**Nominatim:** TBD
**Fallbacks used:** TBD

---

## Errors and Fixes

- **Session 1 (pre-summary) — ncta.org HTTP 403**: northcountrytrail.org blocked bot access. Used alternative sources (BTA site, NPS NOCO page) for NCT Putnam presence confirmation.
- **Session 1 (pre-summary) — NPS ohio.htm HTTP 404**: NPS Ohio page moved. Used NPS park finder and NOCO index instead.
- **Session 1 (pre-summary) — USFWS refuge finder HTTP 404**: Used USFWS refuge locator alternative URL.

---

## Pipeline Stage Log

| Stage | Result | Notes |
|-------|--------|-------|
| Stage 1 — Resolution | — | — |
| Stage 2 — Normalization | — | — |
| Stage 3 — GPS Acquisition | — | — |
| Stage 4 — TSV Output | — | — |
| Stage 4.5 — Vocab Gate | — | — |
| Stage 5 — Integrity Check | — | — |
| Stage 6 — DB Upsert | — | — |

---

## Entity ID Assignments

*(Populated during pipeline stage)*

---

## Open Flags

| Flag ID | Entity | Issue | Resolution Path |
|---------|--------|-------|-----------------|
| PUT-F-01 | DEF-T-001 (NCT) | NCT counties field missing Putnam — DEF-T-001 lists Defiance; Henry; Lucas; Paulding but NCT co-routes through Putnam via BT Delphos Section | Update DEF-T-001.counties to include Putnam during pipeline |
| PUT-F-02 | Ottawa River Greenway | Baseline seed — "Putnam Parks & Pathways" cited as governance; need to verify entity exists and confirm managing organization's legal name and structure | Tier 4 discovery |
| PUT-F-03 | Cascade State Wildlife Area / Cascade Wayside Wildlife Area | Baseline has two differently-named seeds for what appears to be the same ODNR entity; one names it "Cascade State Wildlife Area" (~35 ac) and one "Cascade Wayside Wildlife Area" (36 ac) | Resolve at Tier 2 via ODNR Wildlife Areas page |

---

## Status

**IN PROGRESS** — Session files created 2026-05-07. Tier 1 discovery in progress.
