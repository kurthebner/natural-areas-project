# Putnam County OH — Discovery Handoff
**RUN_ID:** `putnam_oh_2026_05_07`
**PREFIX:** `PUT`
**County:** Putnam, Ohio
**County Seat:** Ottawa
**Last updated:** 2026-05-07 — T1 COMPLETE

---

## Known Multi-County Entities (Bootstrap DB Check — IMP-104 §5)

Pre-discovery DB check run per `processing/na_cross_county_resolution_v5.1.md` §5.

| DB ID | Name | Type | Counties | Scenario | Action at Discovery |
|-------|------|------|----------|----------|---------------------|
| PAU-TR-001 | Miami and Erie Canal Towpath | Trail | Hamilton; Butler; Warren; Montgomery; Miami; Shelby; Auglaize; Allen; **Putnam**; Paulding | A (Paulding-anchored, Putnam presence documented) | At Tier 2: note KNOWN_MC, record PUT supplemental access points if found |
| PAU-TR-003 | Buckeye Trail — Delphos Section | Trail | Paulding; **Putnam**; Allen; Auglaize | A (Paulding-anchored) | At Tier 7: note KNOWN_MC:PAU-TR-003, document Putnam-specific presence |
| DEF-T-001 | North Country National Scenic Trail | Trail | Defiance; Henry; Lucas; Paulding | A (Defiance-anchored; Putnam missing from counties — flag PUT-F-01) | At Tier 1: MC_SUPPLEMENTAL:DEF-T-001; flag counties update needed |
| PAU-TN-001 | North Country National Scenic Trail (network) | Trail Network | Multi-state | A (known network) | At Tier 1: note KNOWN_MC:PAU-TN-001 |

**Held entities from other counties referencing Putnam:** None found in held_entities table.

---

## Tiers Completed

| Tier | Name | Status | Entity Count |
|------|------|--------|-------------|
| T1 | Federal & Tribal | COMPLETE | 1 Trail (NCT — MC_SUPPLEMENTAL:DEF-T-001); all other types null or known_existing |
| T2 | State | PENDING | — |
| T3 | District | PENDING | — |
| T4 | County | PENDING | — |
| T5 | Township | PENDING | — |
| T6 | Municipal | PENDING | — |
| T7 | Conservancy & Land Trust | PENDING | — |
| T8 | Private | PENDING | — |

---

## Tiers Remaining

- **T1 (Federal & Tribal)** — COMPLETE (2026-05-07). 1 Trail record (NCT); all other entity types null or known_existing. IMP-080 verified.
- **T2 (State)** — READY FOR COPILOT (IMP-092 hybrid test). Pre-discovery checklist prepared below.
- **T3–T8** — Not started.

---

## Key Active Flags

| Flag | Description | Resolution Path |
|------|-------------|-----------------|
| PUT-F-01 | DEF-T-001.counties missing Putnam — NCT confirmed through Putnam via BT Delphos Section route | Update DEF-T-001 during pipeline |
| PUT-F-02 | Ottawa River Greenway — "Putnam Parks & Pathways" governance unverified; entity existence uncertain | Tier 4 discovery |
| PUT-F-03 | Cascade State WA vs. Cascade Wayside WA — two baseline names for likely one ODNR entity | Resolve at Tier 2 ODNR Wildlife Areas page |

---

## County Context

**State:** Ohio
**County Seat:** Ottawa
**Major waterways:** Blanchard River (major), Ottawa River (tributary of Auglaize), Portage River headwaters, Miami and Erie Canal corridor (historic)
**Known park districts:** None (no dedicated Putnam County Park District confirmed; "Putnam Parks & Pathways" may be a trails advocacy group rather than a formal park district — verify at Tier 4)
**Metropark affiliations:** None

### Active Townships (15) — from Townships_Officials2022-2023.xlsx

| Township | Notes |
|----------|-------|
| Blanchard | No website URL in roster |
| Greensburg | No website URL in roster |
| Jackson | No website URL in roster |
| Jennings | No website URL in roster |
| Liberty | No website URL in roster |
| Monroe | No website URL in roster |
| Monterey | No website URL in roster |
| Ottawa | No website URL in roster |
| Palmer | No website URL in roster |
| Perry | No website URL in roster |
| Pleasant | No website URL in roster |
| Riley | No website URL in roster |
| Sugar Creek | No website URL in roster |
| Union | No website URL in roster |
| Van Buren | No website URL in roster |

**Note:** No township in Putnam County has a website listed in the 2022-2023 roster. All 15 are confirmed active townships (present in roster = not defunct). At Tier 5, begin with general web searches for each township trustee office before ODNR/county fallback.

### Municipalities (to confirm at Tier 6)

Ottawa (city), Columbus Grove (village), Continental (village), Dupont (village), Gilboa (village), Kalida (village), Leipsic (village), Miller City (village), Ottoville (village), Pandora (village), Belmore (village), Vaughnsville (village), Glandorf (village), McComb (village — may straddle Hancock/Putnam line), Mount Blanchard (village — Hancock?), Blanchard (unincorporated?). Exact list to be confirmed against Ohio Secretary of State or county auditor at Tier 6.

---

## Baseline Seeds

| Seed Name | Type (baseline) | Confirmed | Tier | Notes |
|-----------|----------------|-----------|------|-------|
| Cascade State Wildlife Area | Wildlife Area (~35 ac) | No | T2 | Same entity as "Cascade Wayside WA" below? — PUT-F-03 |
| Cascade Wayside Wildlife Area | State Wildlife Area / Public Hunting (36 ac) | No | T2 | ODW-managed; likely same as above |
| Ottoville Quarry Wildlife Area | State Wildlife Area | No | T2 | Listed on ODNR; "no info on ODNR website yet" — check current ODNR page |
| Putnam County Wildlife Area 1 | Public Hunting Area (ODW) | No | T2 | Generic name — enumerate from ODNR Wildlife Areas list |
| Putnam County Wildlife Area 2 | Public Hunting Area (ODW) | No | T2 | Generic name — enumerate from ODNR Wildlife Areas list |
| Putnam County Wildlife Area 3 | Public Hunting Area (ODW) | No | T2 | Generic name — enumerate from ODNR Wildlife Areas list |
| Ottoville Quarry Wilderness Area | Local Natural Area / Former Quarry (133+ bird spp) | No | T6 | Village of Ottoville governance; Church St, Ottoville; may be same as Ottoville Quarry WA above |
| Ottawa River Greenway | Natural Corridor / Riparian (Putnam P&P) | No | T4 | Governance uncertain — PUT-F-02 |
| Local Nature Preserve (Unnamed) | Local Preserve (Putnam P&P) | No | T4 | Not formally designated; may not qualify as NAP entity |
| Memorial Park (Ottawa) | Municipal Park | No | T6 | Village of Ottawa; 41.020°N -84.047°W |
| Waterworks Park (Ottawa) | Municipal Park | No | T6 | Village of Ottawa; 41.018°N -84.046°W |
| Hall Avenue Park (Columbus Grove) | Municipal Park | No | T6 | Village of Columbus Grove; 40.919°N -84.056°W |
| Ottawa River (Putnam Co. segment) | Stream / Natural Corridor | No | — | GNIS feature entry; likely not a NAP entity (not managed trail or park) |
| Beaver Swamp (historical) | GNIS Swamp type | No | — | Historical/GNIS feature; likely not a NAP entity unless managed preserve found |
| Ottawa Reservoir | Reservoir | No | T4 | Need to determine if publicly accessible managed site |
| Sugarcamp 7 Blanchard Habitat Project | Conservation Area (Private, 9 ac) | No | T8 | Private, not publicly accessible |

---

## Entities Discovered

*(Running table — appended as tiers complete)*

| Entity ID | Name | Type | Tier | Status |
|-----------|------|------|------|--------|
| (pending PUT-T-001) | North Country National Scenic Trail | Trail | T1 | Staged — MC_SUPPLEMENTAL:DEF-T-001; PUT-F-01 counties update required |

---

## Held Entities

*(None at bootstrap)*

---

## Unresolved Baseline Seeds

*(All 16 seeds unresolved at bootstrap — listed in Baseline Seeds table above)*

---

## Open Questions

1. Does Putnam County have a formal park district, or is "Putnam Parks & Pathways" an informal trails group? — Verify at Tier 4.
2. Are "Cascade State Wildlife Area" and "Cascade Wayside Wildlife Area" the same ODNR entity? — Verify at Tier 2.
3. Is "Ottoville Quarry Wilderness Area" (Village of Ottoville, baseline) separate from or the same as "Ottoville Quarry Wildlife Area" (ODW-managed, baseline)? — Local municipal parks + ODNR list comparison at Tier 2 and Tier 6.
4. Does the NCT physically enter Putnam County, or does it terminate at the Paulding/Putnam county line? — Verify at Tier 1 via BTA Delphos Section map.
5. What is the exact municipality list for Putnam County? — Confirm at Tier 6 via Ohio Secretary of State.
6. Does Ottawa Reservoir have public access as a managed site? — Check at Tier 4 or T2 (if ODNR-managed).

---

## Next Steps

1. **Complete Tier 1 discovery** (current session): Fetch NPS NOCO, BTA Delphos Section map, USFWS refuge finder, Army Corps project locator. Stage results. Close tier with IMP-080 file check.
2. **Hand Tier 2 to Copilot** (IMP-092 hybrid test): See pre-discovery checklist below. Copilot fetches ODNR pages and produces a flat table; Claude writes YAML and verifies vocabulary.
3. **Tiers 3–8** — Claude-only per standard protocol.

---

## Pre-Discovery Checklist — Tier 1 (Federal & Tribal) — COMPLETE

- [x] NPS — North Country National Scenic Trail (NOCO): https://www.nps.gov/noco/index.htm — loaded; maps page confirmed; NCT multi-state trail
- [x] NPS — Putnam County site search — no NPS-managed sites in county
- [x] USFWS — Refuge finder, Putnam County OH — 404 on county query; no NWR found
- [x] Army Corps of Engineers — no USACE impoundments in Putnam County
- [x] BLM — confirmed no Ohio BLM surface land (Wayne NF only, SE Ohio)
- [x] BTA — Delphos Section (buckeyetrail.org/sections/delphos.php) — page too large; Putnam confirmed via PAU-TR-003 DB record
- [x] Tribal — confirmed no tribal trust lands in Putnam County (Ottawa Tribe ancestral only)

---

## Pre-Discovery Checklist — Tier 2 (State) — FOR COPILOT

*Copilot handles web research; returns flat table. Claude writes YAML and verifies vocabulary.*

**Primary ODNR sources to fetch:**

- [ ] ODNR Wildlife Areas — Putnam County filter: https://ohiodnr.gov/discover-and-learn/safety-conservation/wildlife-management/wildlife-areas
- [ ] ODNR Public Hunting Areas — Putnam County: search "Putnam" on https://ohiodnr.gov/discover-and-learn/safety-conservation/wildlife-management/public-hunting-areas
- [ ] ODNR Nature Preserves — Putnam County: https://ohiodnr.gov/go-and-do/plan-a-visit/find-a-property/nature-preserves
- [ ] Ohio Canal Lands — Miami and Erie Canal, Putnam County segment: https://ohiodnr.gov/discover-and-learn/safety-conservation/about-ODNR/real-estate/ohio-canal-maps/miami-erie-canal-maps
- [ ] ODNR State Forests — Putnam County (confirm none): https://ohiodnr.gov/go-and-do/plan-a-visit/find-a-property/state-forests
- [ ] ODNR State Parks — Putnam County (confirm none): https://ohiodnr.gov/go-and-do/plan-a-visit/find-a-property/state-parks

**For each entity found, Copilot should capture:**

| Field | Notes |
|-------|-------|
| Name (exact from ODNR page) | |
| Entity type (Wildlife Area / Nature Preserve / State Forest / etc.) | |
| Acres | |
| Address or location description | |
| County (confirm Putnam) | |
| Managing division (Division of Wildlife / Division of Natural Areas & Preserves / etc.) | |
| URL of source page | |
| Any GPS coordinates listed | |
| Any trails mentioned | |
| Any access points / boat ramps / parking areas mentioned | |

**Specific seeds to investigate:**
- "Cascade State Wildlife Area" / "Cascade Wayside Wildlife Area" — are these the same entity? What is the official ODNR name?
- "Putnam County Wildlife Area 1/2/3" — enumerate all ODW public hunting areas in Putnam County with official names
- "Ottoville Quarry Wildlife Area" — confirm presence on ODNR list; get official name and acreage
- Miami and Erie Canal corridor in Putnam County — confirm ODNR management, any formally managed segments, any named access sites

**Copilot output format requested:** Flat table with one row per entity, columns as listed above. No YAML — Claude handles YAML.

---

## Captured Source Data

*(Populated at fetch time as sources are visited. GPS left blank at discovery; filled during map verification or GPS acquisition.)*

### Tier 1 — Federal & Tribal (COMPLETE 2026-05-07)

| Source | URL | Content | GPS Captured |
|--------|-----|---------|-------------|
| NPS NOCO Maps | https://www.nps.gov/noco/planyourvisit/maps.htm | Maps page — confirms NCT as multi-state trail across 8 states including Ohio; no Putnam-specific data | No |
| NCTA Ohio | https://northcountrytrail.org/the-trail/ohio/ | Ohio state page — response too large for text extraction; NCT confirmed in Ohio via DB PAU-TR-003 cross-reference | No |
| BTA Delphos Section | https://buckeyetrail.org/sections/delphos.php | **Confirmed via Chrome** — Counties: Auglaize, Allen, Putnam, Paulding. Miles: 46.5 total / 22.7 off-road. Chapter: Miami and Erie Canal Chapter. Trail towns: Spencerville, Kossuth, Fort Jennings, Delphos, Ottoville. Putnam County towns: **Fort Jennings, Ottoville**. Northern terminus at Junction (Paulding County). Abutting sections: St. Marys (south), Defiance (north). Emergency services table explicitly lists Putnam County (sheriff 419.523.3208). No federal trailheads documented for Putnam County portion. Page last updated Mar 14, 2026. | No |
| USFWS fws.gov | https://www.fws.gov/ | Refuge finder — county-specific query returned 404; no NWR in Putnam County | No |
| USACE | (knowledge-based) | No USACE impoundments in Putnam County confirmed | No |
| BLM | (knowledge-based) | No Ohio BLM surface land; Wayne NF in SE Ohio only | No |
| NPS NHA list | (knowledge-based) | No NHA designation covers Putnam County | No |
| Tribal/BIA | (knowledge-based) | No tribal trust land in Putnam County; Ottawa Tribe ancestral connection only | No |

