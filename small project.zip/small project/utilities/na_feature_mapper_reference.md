# Canonical Feature Mapper — Natural Areas Project

Copy `FEATURE_MAP` into each county pipeline script as the starting point. Extend with
county-specific patterns below the canonical list. Do not modify the canonical entries —
add county-specific overrides as additional tuples after the last canonical entry.

All patterns are case-insensitive regex matched against `features_raw`. The right-hand value
must be an exact term from the site vocabulary §6.2 features list. Extend the map when a
county uses a raw term that has no current pattern; never leave an out-of-vocabulary value
in the `features` TSV column.

```python
FEATURE_MAP = [
    # hiking / walking
    (r'hiking trail|walking trail|walking path|winding trail|nature trail|loop trail|trail system|interpretive trail|self.guided interpretive', "Hiking Trail"),
    (r'boardwalk',                   "Boardwalk"),
    (r'interpretive trail|self.guided interpretive', "Interpretive Sign"),
    (r'bridle trail|equestrian',     "Bridle Trail"),
    # water
    (r'boat ramp|launch ramp',       "Boat Ramp"),
    (r'boat launch|watercraft|canoe|kayak', "Watercraft Access"),
    (r'fishing pond|fishing lake',   "Fishing Area"),
    (r'fishing pond',                "Pond"),
    (r'swimming beach|swim beach',   "Swimming Beach"),
    (r'swimming pool|city pool',     "Swimming Pool"),
    (r'splash pad|spray pad',        "Spray Park"),
    # picnic / shelter
    (r'pavilion|shelter house|open air pavilion|rentable.*shelter|covered seating', "Pavilion"),
    (r'picnic area|picnic spot|picnic table', "Picnic Area"),
    (r'gazebo',                      "Gazebo"),
    # sports
    (r'baseball|softball',           "Ball Diamond"),
    (r'basketball court',            "Basketball Court"),
    (r'tennis court',                "Tennis Court"),
    (r'pickleball court',            "Pickleball Court"),
    (r'volleyball court|sand volleyball', "Volleyball Court"),
    (r'soccer field|soccer complex', "Soccer Pitch"),
    (r'football field',              "Football Field"),
    (r'disc golf',                   "Disc Golf Course"),
    (r'skate park|skate ramp',       "Skate Park"),
    (r'miniature golf',              "Mini Golf"),
    # recreation
    (r'playground|play equipment',   "Playground"),
    (r'sledding hill',               "Sledding Hill"),
    (r'horseshoe',                   "Horseshoe Pitch"),
    (r'archery',                     "Archery Range"),
    (r'ropes course|high ropes',     "Ropes Course"),
    (r'shooting sports|shooting range', "Shooting Range"),
    (r'dog park',                    "Dog Park"),
    # amenities
    (r'restroom|flush toilet|portable toilet|bathroom', "Restrooms"),
    (r'parking',                     "Parking Lot"),
    (r'kiosk|information kiosk',     "Kiosk"),
    (r'camping|campsite',            "Camping"),
    (r'cabin|camper cabin|yurt',     "Cabin Rentals"),
    (r'ADA.compliant|ADA accessible|wheelchair', "ADA Accessible"),
    # natural
    (r'observation deck',            "Observation Deck"),
    (r'vernal pool',                 "Vernal Pool"),
    (r'hunting area|public hunting', "Hunting Area"),
    (r'wildlife viewing|wildlife.*observation', "Wildlife Observation Area"),
    # historical
    (r'historic.*depot|train depot|caboose|railroad artifact', "Historic Structure"),
    (r'war memorial|memorial statue|monument|WWI|military monument', "Monument"),
    # educational / farm
    (r'nature center|nature lab',    "Nature Center"),
    (r'guided.*tour|wagon tour|tractor.*tour', "Guided Tours"),
    (r'farm store|bison.*store',     "Farm Store"),
    # misc
    (r'pollinator garden',           "Pollinator Garden"),
    # --- add county-specific patterns below this line ---
]
```

## Terms with No Vocabulary Equivalent

The following raw terms have no matching controlled vocabulary term and must remain in
`features_raw` only — never in the `features` TSV column:

- Concession Stand
- Dump Station
- Water Frontage (IMP-038)

If a new raw term is found that does not map to any vocabulary term, add it to this list
rather than inventing a new vocabulary value. New vocabulary terms require a vocabulary
module update and a version increment.
